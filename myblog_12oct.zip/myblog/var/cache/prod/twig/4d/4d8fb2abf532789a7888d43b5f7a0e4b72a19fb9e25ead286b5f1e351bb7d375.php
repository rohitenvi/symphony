<?php

/* frontend/singlenews.html.twig */
class __TwigTemplate_15e07bf4d9f3721be2db9ebce873583cd66c469384aa84d0a620d251c5aafa7c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("home.html.twig", "frontend/singlenews.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "home.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84ffa950d2a0555be8e11aa00172499cab68b8cc02dd3092038377e7f617c4a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84ffa950d2a0555be8e11aa00172499cab68b8cc02dd3092038377e7f617c4a8->enter($__internal_84ffa950d2a0555be8e11aa00172499cab68b8cc02dd3092038377e7f617c4a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontend/singlenews.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_84ffa950d2a0555be8e11aa00172499cab68b8cc02dd3092038377e7f617c4a8->leave($__internal_84ffa950d2a0555be8e11aa00172499cab68b8cc02dd3092038377e7f617c4a8_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_ccb1f931decba8f897e692edb36da6bf9dba6c9967e4e573b611c3c05f53b278 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccb1f931decba8f897e692edb36da6bf9dba6c9967e4e573b611c3c05f53b278->enter($__internal_ccb1f931decba8f897e692edb36da6bf9dba6c9967e4e573b611c3c05f53b278_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<section class=\"article-slider detail-slider\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-12 col-sm-12 col-xs-12 pad-0\">
            <a href=\"#\">Back To Resource</a>

        </div>
        <div class=\"col-md-offset-3 col-md-6\">
            <h2 class=\"text-center\">
                <span>";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["allnews"]) ? $context["allnews"] : $this->getContext($context, "allnews")), "name", array()), "html", null, true);
        echo " </span>
               
            </h2>
            <h3 class=\"text-center\">By ";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["allnews"]) ? $context["allnews"] : $this->getContext($context, "allnews")), "author", array()), "html", null, true);
        echo "</h3>
            <p class=\"text-center\">Publication Date: ";
        // line 16
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["allnews"]) ? $context["allnews"] : $this->getContext($context, "allnews")), "added", array()), "d/m/Y"), "html", null, true);
        echo " </p>
           <div class=\"text-center \"> <img src=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "uploads/newsimages/";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["allnews"]) ? $context["allnews"] : $this->getContext($context, "allnews")), "imagePath", array()), "html", null, true);
        echo " \"></div>
            <p class=\"text-center\">Photo credit: <span>@ ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["allnews"]) ? $context["allnews"] : $this->getContext($context, "allnews")), "imageCredit", array()), "html", null, true);
        echo "</span> </p>
             </div>
        </div>
    </div>
</section>
<section class=\"detail-page-content about-diagram light\">
    <div class=\"container\">
        <div class=\"col-md-6  col-md-offset-3 col-sm-12 col-xs-12\">
        ";
        // line 26
        echo $this->getAttribute((isset($context["allnews"]) ? $context["allnews"] : $this->getContext($context, "allnews")), "newsContent", array());
        echo " 
        </div>
    </div>
</section>

<section class=\"share-resource\">
    <div class=\"contanier\">
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12\" >
                <h2>Share Resource</h2>
                <form class=\"link-bar\">
                    <div class=\"input-group\">
                      <input type=\"text\" class=\"link-input\" placeholder=\"https://humanbehaviourchange.org/resources/linkname-20132142151\" name=\"search\">
                      <div class=\"input-group-btn\">
                        <button class=\"btn copy-btn\" type=\"submit\">Copy Link</button>
                      </div>
                    </div>
                  </form>
               <p>Share with Networks</p>
               <ul class=\"social-icons\">
                   <li><a href=\"#\"><img src=\"images/fb.png\" alt=\"social-icon\"></a></li>
                   <li><a href=\"#\"><img src=\"images/tw.png\" alt=\"social-icon\"></a></li>
                   <li><a href=\"#\"><img src=\"images/li.png\" alt=\"social-icon\"></a></li>
               </ul>
            </div>
        </div>
    </div>
</section>
<section class=\"back-btn\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12 col-sm-12 col-xs-12\">
                <a href=\"#\" class=\"btn\">Back To Resource</a>
            </div>
        </div>
    </div>
</section>

";
        
        $__internal_ccb1f931decba8f897e692edb36da6bf9dba6c9967e4e573b611c3c05f53b278->leave($__internal_ccb1f931decba8f897e692edb36da6bf9dba6c9967e4e573b611c3c05f53b278_prof);

    }

    public function getTemplateName()
    {
        return "frontend/singlenews.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 26,  71 => 18,  65 => 17,  61 => 16,  57 => 15,  51 => 12,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'home.html.twig' %}
{% block body %}
<section class=\"article-slider detail-slider\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-12 col-sm-12 col-xs-12 pad-0\">
            <a href=\"#\">Back To Resource</a>

        </div>
        <div class=\"col-md-offset-3 col-md-6\">
            <h2 class=\"text-center\">
                <span>{{allnews.name}} </span>
               
            </h2>
            <h3 class=\"text-center\">By {{allnews.author}}</h3>
            <p class=\"text-center\">Publication Date: {{ allnews.added |date(\"d/m/Y\") }} </p>
           <div class=\"text-center \"> <img src=\"{{ url('homepage') }}uploads/newsimages/{{ allnews.imagePath }} \"></div>
            <p class=\"text-center\">Photo credit: <span>@ {{ allnews.imageCredit }}</span> </p>
             </div>
        </div>
    </div>
</section>
<section class=\"detail-page-content about-diagram light\">
    <div class=\"container\">
        <div class=\"col-md-6  col-md-offset-3 col-sm-12 col-xs-12\">
        {{  allnews.newsContent |raw('html')}} 
        </div>
    </div>
</section>

<section class=\"share-resource\">
    <div class=\"contanier\">
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12\" >
                <h2>Share Resource</h2>
                <form class=\"link-bar\">
                    <div class=\"input-group\">
                      <input type=\"text\" class=\"link-input\" placeholder=\"https://humanbehaviourchange.org/resources/linkname-20132142151\" name=\"search\">
                      <div class=\"input-group-btn\">
                        <button class=\"btn copy-btn\" type=\"submit\">Copy Link</button>
                      </div>
                    </div>
                  </form>
               <p>Share with Networks</p>
               <ul class=\"social-icons\">
                   <li><a href=\"#\"><img src=\"images/fb.png\" alt=\"social-icon\"></a></li>
                   <li><a href=\"#\"><img src=\"images/tw.png\" alt=\"social-icon\"></a></li>
                   <li><a href=\"#\"><img src=\"images/li.png\" alt=\"social-icon\"></a></li>
               </ul>
            </div>
        </div>
    </div>
</section>
<section class=\"back-btn\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12 col-sm-12 col-xs-12\">
                <a href=\"#\" class=\"btn\">Back To Resource</a>
            </div>
        </div>
    </div>
</section>

{% endblock %}", "frontend/singlenews.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/frontend/singlenews.html.twig");
    }
}
