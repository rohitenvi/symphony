<?php

/* /admin/resourcetype/allresources.html.twig */
class __TwigTemplate_57151248c165dd26e0478937f28201afcae3722bfb5008f844b1cf618a175755 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("adminlayout.html.twig", "/admin/resourcetype/allresources.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "adminlayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35c79945bd881e2ac2a49a95a43d361e149ecc89d2ef825be1ae8b52e67a5c1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35c79945bd881e2ac2a49a95a43d361e149ecc89d2ef825be1ae8b52e67a5c1a->enter($__internal_35c79945bd881e2ac2a49a95a43d361e149ecc89d2ef825be1ae8b52e67a5c1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/admin/resourcetype/allresources.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_35c79945bd881e2ac2a49a95a43d361e149ecc89d2ef825be1ae8b52e67a5c1a->leave($__internal_35c79945bd881e2ac2a49a95a43d361e149ecc89d2ef825be1ae8b52e67a5c1a_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_e48ce90d7acddbdd4e9e46237b32e904cf7088f4e6399c1f1f0757b430df67c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e48ce90d7acddbdd4e9e46237b32e904cf7088f4e6399c1f1f0757b430df67c9->enter($__internal_e48ce90d7acddbdd4e9e46237b32e904cf7088f4e6399c1f1f0757b430df67c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"page-wrapper\">
   <div class=\"container-fluid\">

\t\t\t\t
\t\t\t\t<!-- Row -->
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"panel panel-default card-view\">
\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t\t\t\t<h6 class=\"panel-title txt-dark\">Resource Type</h6>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/resourcetype/create\"><button type=\"button\" class=\"btn btn-success\">Create A New </button></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"panel-wrapper collapse in\">
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"table-wrap\">
\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t\t\t\t\t\t\t<table id=\"datable_1\" class=\"table table-hover display  pb-30\" >
\t\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t        <tr>
\t\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Name</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Created</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</thead>

\t\t\t\t\t\t\t\t\t\t\t\t<tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Name</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Created</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tbody>
                                                  ";
        // line 45
        $context["myVal"] = 1;
        // line 46
        echo "
                                        ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resourcestypes"]) ? $context["resourcestypes"] : $this->getContext($context, "resourcestypes")));
        foreach ($context['_seq'] as $context["_key"] => $context["resource"]) {
            // line 48
            echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 49
            echo twig_escape_filter($this->env, (isset($context["myVal"]) ? $context["myVal"] : $this->getContext($context, "myVal")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["resource"], "name", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 51
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["resource"], "createdtime", array()), "d/m/Y"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 52
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["resource"], "updatedtime", array()), "d/m/Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 54
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
            echo "admin/resourcetype/edit/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resource"], "id", array()), "html", null, true);
            echo "\">
                                        <button class=\"btn btn-warning btn-icon-anim btn-circle\">
                                         <i class=\"fa fa-pencil\"></i>
                                         </button></a>

\t\t\t\t\t\t\t\t\t\t<a class=\"confirmation\" href =\"";
            // line 59
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
            echo "admin/resourcetype/delete/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resource"], "id", array()), "html", null, true);
            echo "\"><button class=\"btn btn-danger btn-icon-anim btn-circle\">
                                             <i class=\"icon-trash\"></i>
                                                        </button></a>
                                                        </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t ";
            // line 64
            $context["myVal"] = ((isset($context["myVal"]) ? $context["myVal"] : $this->getContext($context, "myVal")) + 1);
            // line 65
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resource'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "\t\t\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- /Row -->
\t\t\t\t ";
        
        $__internal_e48ce90d7acddbdd4e9e46237b32e904cf7088f4e6399c1f1f0757b430df67c9->leave($__internal_e48ce90d7acddbdd4e9e46237b32e904cf7088f4e6399c1f1f0757b430df67c9_prof);

    }

    public function getTemplateName()
    {
        return "/admin/resourcetype/allresources.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 67,  138 => 65,  136 => 64,  126 => 59,  116 => 54,  111 => 52,  107 => 51,  103 => 50,  99 => 49,  96 => 48,  92 => 47,  89 => 46,  87 => 45,  55 => 16,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'adminlayout.html.twig' %}
{% block body %}
<div class=\"page-wrapper\">
   <div class=\"container-fluid\">

\t\t\t\t
\t\t\t\t<!-- Row -->
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"panel panel-default card-view\">
\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t\t\t\t<h6 class=\"panel-title txt-dark\">Resource Type</h6>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t<a href=\"{{ url('homepage') }}admin/resourcetype/create\"><button type=\"button\" class=\"btn btn-success\">Create A New </button></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"panel-wrapper collapse in\">
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"table-wrap\">
\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t\t\t\t\t\t\t<table id=\"datable_1\" class=\"table table-hover display  pb-30\" >
\t\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t        <tr>
\t\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Name</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Created</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</thead>

\t\t\t\t\t\t\t\t\t\t\t\t<tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Name</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Created</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tbody>
                                                  {% set myVal = 1 %}

                                        {% for resource in resourcestypes %}
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>{{ myVal }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ resource.name }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{resource.createdtime |date(\"d/m/Y\")  }} </td>
\t\t\t\t\t\t\t\t\t\t<td>{{ resource.updatedtime | date(\"d/m/Y\")  }}</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ url('homepage') }}admin/resourcetype/edit/{{resource.id}}\">
                                        <button class=\"btn btn-warning btn-icon-anim btn-circle\">
                                         <i class=\"fa fa-pencil\"></i>
                                         </button></a>

\t\t\t\t\t\t\t\t\t\t<a class=\"confirmation\" href =\"{{ url('homepage') }}admin/resourcetype/delete/{{resource.id}}\"><button class=\"btn btn-danger btn-icon-anim btn-circle\">
                                             <i class=\"icon-trash\"></i>
                                                        </button></a>
                                                        </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t {% set myVal = myVal + 1 %}

\t\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- /Row -->
\t\t\t\t {% endblock %}", "/admin/resourcetype/allresources.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/admin/resourcetype/allresources.html.twig");
    }
}
