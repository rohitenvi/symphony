<?php

/* frontend/computerscience.html.twig */
class __TwigTemplate_0848270adf5c04117a0f86fcf91dd416c074a8bcbdd7c6064219214d60fe5aa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("home.html.twig", "frontend/computerscience.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "home.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_36853b3b71a864cdd85a91fae666227ee79a042eeac8f76c3a10c81cca5e972b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36853b3b71a864cdd85a91fae666227ee79a042eeac8f76c3a10c81cca5e972b->enter($__internal_36853b3b71a864cdd85a91fae666227ee79a042eeac8f76c3a10c81cca5e972b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontend/computerscience.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_36853b3b71a864cdd85a91fae666227ee79a042eeac8f76c3a10c81cca5e972b->leave($__internal_36853b3b71a864cdd85a91fae666227ee79a042eeac8f76c3a10c81cca5e972b_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_16c1c04d3f1c8b960f8fa84761073102ae17d6ee01a80bb54d63fe790949e0b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16c1c04d3f1c8b960f8fa84761073102ae17d6ee01a80bb54d63fe790949e0b7->enter($__internal_16c1c04d3f1c8b960f8fa84761073102ae17d6ee01a80bb54d63fe790949e0b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<section class=\"slider slider-3\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-8 pad-0\">
            <h2>
                <span>Computer Science</span>
                <img class=\"hidden visible-xs\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/homegraphic-cs.svg"), "html", null, true);
        echo "\" alt=\"mob-home\">
            </h2>
            <p>The Human Behaviour Change Project is a collaboration between world leading institution to create and develop a Machine Learning Programme that can analyse and literature and no more text</p>
             </div>
        </div>
    </div>
</section>

<section class=\"cs-section text-center\">
    <div id=\"exTab2\" class=\"\">
        <div class=\"\">
        <ul class=\"nav nav-tabs cs-tab\">
            <li>
        <a href=\"#1\" data-toggle=\"tab\">Project</a>
            </li>
            <li><a href=\"#2\" data-toggle=\"tab\">Behavioural Science</a>
            </li>
               <li class=\"active\" >
        <a href=\"#3\" data-toggle=\"tab\">Computer Science</a>
            </li>
            <li><a href=\"#4\" data-toggle=\"tab\">System Architecture</a>
            </li>
        </ul>

         <!--- MObile view -->

        <div class=\"\">
        <div class=\"col-sm-12 cs-tab\">
        <span class=\"d-hd\">Department</span>
        <div class=\"select-box-department\">
                <select>
                    <option > Project</option>
                    <option> Behavioural Science</option>
                    <option>Computer Science</option>
                    <option>System Architecture</option>
                </select>
        </div>
        </div>
        </div>


            <div class=\"tab-content \">

            <!-- MObile view -->
                <div class=\"container\">
                <div class=\"row\">
                <div class=\"col-md-12 col-sm-12 col-xs-12 dropdown\">
                <button id=\"dp\">Filter Resources (3 applied)</button>
                </div>
                </div>
                </div>
              
                <div class=\"tab-pane active\" id=\"3\">
                    

                <div class=\"\">
                <div>

                <!---  Filter Start -->

                <div class=\" pad-35 sh\" >
                <div class=\"container\">
                <div class=\"row\">
                

                <div class=\"col-md-4 col-sm-12 col-xs-12 t-center\">
                <div class=\" text-right inline-div\"> <span>Category</span></div>
                <div class=\"select-box\">
                <select class=\"selectpicker\">
               ";
        // line 78
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allcomputerscats"]) ? $context["allcomputerscats"] : $this->getContext($context, "allcomputerscats")));
        foreach ($context['_seq'] as $context["_key"] => $context["cats"]) {
            // line 79
            echo "                <option value=\"\">-Select-</option>
                <option value=\"";
            // line 80
            echo twig_escape_filter($this->env, $this->getAttribute($context["cats"], "id", array()), "html", null, true);
            echo "\"> ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["cats"], "name", array()), "html", null, true);
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cats'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 82
        echo "                </select>
                </div>
                </div>
                            


                <div class=\"col-md-4 col-sm-12 col-xs-12 t-center\">
                <div class=\" text-right inline-div\"><span>ResourceType</span></div>
                <div class=\"select-box text-cnetr\">
                <select class=\"selectpicker\">
                <option value=\"\">-Select-</option>
                ";
        // line 93
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allresourcetypes"]) ? $context["allresourcetypes"] : $this->getContext($context, "allresourcetypes")));
        foreach ($context['_seq'] as $context["_key"] => $context["allresourcetype"]) {
            // line 94
            echo "                <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["allresourcetype"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["allresourcetype"], "name", array()), "html", null, true);
            echo "</option>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['allresourcetype'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "                </select>
                </div>
                </div>

                <div class=\"col-md-4 col-sm-12 col-xs-12 t-center\">
                <div class=\" text-right inline-div\"><span>sort by</span></div>
                <div class=\"select-box-2 \">
                <select class=\"selectpicker\">
                <option> Date (Asc To Desc)</option>
                <option> Date (Desc To Asc)</option>
                </select>
                </div>
                </div>

                </div>
                </div>
                </div>

             <!--  filter  ends -->

        <div class=\"clearfix\"></div>
       
           <!--- Tab Body Start -->
 
           <div class=\"\">
            
            <div class=\"panel-body\">
            <div class=\"container\">
            <span class=\"text-download\">
            <p>17/07/2017</p>
            <span>  A link to some sort of resource like powerpoint slide or paper
            <a class=\"link-text\">PDF</a></span>
            <a href=\"#\" class=\"api-btn\">API Documentation</a>
            </span>
            <span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
            </div>

            <div class=\"panel-body light\">
            <div class=\"container\">
            <span class=\"text-download\">
            <p>1/07/2017</p>
            <span>  Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span>
            <a href=\"#\" class=\"api-btn\">Computery category</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
           </div>

            <div class=\"panel-body \">
            <div class=\"container\">
            <span class=\"text-download\">
            <p>17/07/2017</p><span>  Matrix Tool or example of another link Website<a class=\"link-text\">website</a></span>
            <a href=\"#\" class=\"api-btn\">Miscellaneous</a></span>
            <span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
           </div>
        
          </div>

          </div>   <!--  65 -->


        </div>    <!--  64 -->


        </div>
      </div> <!--   50 -->



    </div> <!--  19 -->
    </div>  <!--  18 -->
</section>
";
        
        $__internal_16c1c04d3f1c8b960f8fa84761073102ae17d6ee01a80bb54d63fe790949e0b7->leave($__internal_16c1c04d3f1c8b960f8fa84761073102ae17d6ee01a80bb54d63fe790949e0b7_prof);

    }

    public function getTemplateName()
    {
        return "frontend/computerscience.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 96,  154 => 94,  150 => 93,  137 => 82,  127 => 80,  124 => 79,  120 => 78,  48 => 9,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'home.html.twig' %}
{% block body %}
<section class=\"slider slider-3\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-8 pad-0\">
            <h2>
                <span>Computer Science</span>
                <img class=\"hidden visible-xs\" src=\"{{ asset('vendors/frontend/images/homegraphic-cs.svg') }}\" alt=\"mob-home\">
            </h2>
            <p>The Human Behaviour Change Project is a collaboration between world leading institution to create and develop a Machine Learning Programme that can analyse and literature and no more text</p>
             </div>
        </div>
    </div>
</section>

<section class=\"cs-section text-center\">
    <div id=\"exTab2\" class=\"\">
        <div class=\"\">
        <ul class=\"nav nav-tabs cs-tab\">
            <li>
        <a href=\"#1\" data-toggle=\"tab\">Project</a>
            </li>
            <li><a href=\"#2\" data-toggle=\"tab\">Behavioural Science</a>
            </li>
               <li class=\"active\" >
        <a href=\"#3\" data-toggle=\"tab\">Computer Science</a>
            </li>
            <li><a href=\"#4\" data-toggle=\"tab\">System Architecture</a>
            </li>
        </ul>

         <!--- MObile view -->

        <div class=\"\">
        <div class=\"col-sm-12 cs-tab\">
        <span class=\"d-hd\">Department</span>
        <div class=\"select-box-department\">
                <select>
                    <option > Project</option>
                    <option> Behavioural Science</option>
                    <option>Computer Science</option>
                    <option>System Architecture</option>
                </select>
        </div>
        </div>
        </div>


            <div class=\"tab-content \">

            <!-- MObile view -->
                <div class=\"container\">
                <div class=\"row\">
                <div class=\"col-md-12 col-sm-12 col-xs-12 dropdown\">
                <button id=\"dp\">Filter Resources (3 applied)</button>
                </div>
                </div>
                </div>
              
                <div class=\"tab-pane active\" id=\"3\">
                    

                <div class=\"\">
                <div>

                <!---  Filter Start -->

                <div class=\" pad-35 sh\" >
                <div class=\"container\">
                <div class=\"row\">
                

                <div class=\"col-md-4 col-sm-12 col-xs-12 t-center\">
                <div class=\" text-right inline-div\"> <span>Category</span></div>
                <div class=\"select-box\">
                <select class=\"selectpicker\">
               {% for cats in allcomputerscats %}
                <option value=\"\">-Select-</option>
                <option value=\"{{cats.id}}\"> {{cats.name}}</option>
                {% endfor %}
                </select>
                </div>
                </div>
                            


                <div class=\"col-md-4 col-sm-12 col-xs-12 t-center\">
                <div class=\" text-right inline-div\"><span>ResourceType</span></div>
                <div class=\"select-box text-cnetr\">
                <select class=\"selectpicker\">
                <option value=\"\">-Select-</option>
                {% for allresourcetype in allresourcetypes%}
                <option value=\"{{allresourcetype.id}}\">{{allresourcetype.name}}</option>
                {% endfor%}
                </select>
                </div>
                </div>

                <div class=\"col-md-4 col-sm-12 col-xs-12 t-center\">
                <div class=\" text-right inline-div\"><span>sort by</span></div>
                <div class=\"select-box-2 \">
                <select class=\"selectpicker\">
                <option> Date (Asc To Desc)</option>
                <option> Date (Desc To Asc)</option>
                </select>
                </div>
                </div>

                </div>
                </div>
                </div>

             <!--  filter  ends -->

        <div class=\"clearfix\"></div>
       
           <!--- Tab Body Start -->
 
           <div class=\"\">
            
            <div class=\"panel-body\">
            <div class=\"container\">
            <span class=\"text-download\">
            <p>17/07/2017</p>
            <span>  A link to some sort of resource like powerpoint slide or paper
            <a class=\"link-text\">PDF</a></span>
            <a href=\"#\" class=\"api-btn\">API Documentation</a>
            </span>
            <span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
            </div>

            <div class=\"panel-body light\">
            <div class=\"container\">
            <span class=\"text-download\">
            <p>1/07/2017</p>
            <span>  Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span>
            <a href=\"#\" class=\"api-btn\">Computery category</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
           </div>

            <div class=\"panel-body \">
            <div class=\"container\">
            <span class=\"text-download\">
            <p>17/07/2017</p><span>  Matrix Tool or example of another link Website<a class=\"link-text\">website</a></span>
            <a href=\"#\" class=\"api-btn\">Miscellaneous</a></span>
            <span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
           </div>
        
          </div>

          </div>   <!--  65 -->


        </div>    <!--  64 -->


        </div>
      </div> <!--   50 -->



    </div> <!--  19 -->
    </div>  <!--  18 -->
</section>
{% endblock %}", "frontend/computerscience.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/frontend/computerscience.html.twig");
    }
}
