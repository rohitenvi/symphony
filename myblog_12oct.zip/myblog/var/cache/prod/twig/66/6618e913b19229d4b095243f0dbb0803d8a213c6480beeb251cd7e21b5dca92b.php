<?php

/* /admin/resources/allresources.html.twig */
class __TwigTemplate_015f774524915449def0caff3efaf207e32dab2d4a405946d21413cf755ed27b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("adminlayout.html.twig", "/admin/resources/allresources.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "adminlayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_750f0359a641c8c1ecb697da8284a61dedf5605d79b5287b6f82ee30612d2ebb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_750f0359a641c8c1ecb697da8284a61dedf5605d79b5287b6f82ee30612d2ebb->enter($__internal_750f0359a641c8c1ecb697da8284a61dedf5605d79b5287b6f82ee30612d2ebb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/admin/resources/allresources.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_750f0359a641c8c1ecb697da8284a61dedf5605d79b5287b6f82ee30612d2ebb->leave($__internal_750f0359a641c8c1ecb697da8284a61dedf5605d79b5287b6f82ee30612d2ebb_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_f09327651e1cdb9d5ca9701ee6b1d6157ab4fee9ecb50d7de27b83cffba40734 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f09327651e1cdb9d5ca9701ee6b1d6157ab4fee9ecb50d7de27b83cffba40734->enter($__internal_f09327651e1cdb9d5ca9701ee6b1d6157ab4fee9ecb50d7de27b83cffba40734_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"page-wrapper\">
   <div class=\"container-fluid\">

\t\t\t\t
\t\t\t\t<!-- Row -->
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"panel panel-default card-view\">
\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t\t\t\t<h6 class=\"panel-title txt-dark\">Resources</h6>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/resource/createnew\"><button type=\"button\" class=\"btn btn-success\">Create A New </button></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"panel-wrapper collapse in\">
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"table-wrap\">
\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t\t\t\t\t\t\t<table id=\"datable_1\" class=\"table table-hover display  pb-30\" >
\t\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Title</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Type</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Path Url</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Category</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Type 0f Resource(if available)</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Added Date</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified Date</th>
\t\t\t\t\t\t\t\t\t\t\t     <th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t\t\t\t<tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Title</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Type</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Path Url</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Category</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Type 0f Resource(if available)</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Added Date</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified Date</th>
\t\t\t\t\t\t\t\t\t\t\t     <th>Actions</th>\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tbody>
                                                  ";
        // line 52
        $context["myVal"] = 1;
        // line 53
        echo "                                                   ";
        $context["mycat"] = 0;
        echo " 
                       ";
        // line 54
        $context["catcount"] = twig_length_filter($this->env, (isset($context["catdata"]) ? $context["catdata"] : $this->getContext($context, "catdata")));
        // line 55
        echo "               ";
        $context["heirchycount"] = twig_length_filter($this->env, (isset($context["resourcetype"]) ? $context["resourcetype"] : $this->getContext($context, "resourcetype")));
        echo "               
                                         ";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["alldatas"]) ? $context["alldatas"] : $this->getContext($context, "alldatas")));
        foreach ($context['_seq'] as $context["_key"] => $context["todo"]) {
            // line 57
            echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 58
            echo twig_escape_filter($this->env, (isset($context["myVal"]) ? $context["myVal"] : $this->getContext($context, "myVal")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "title", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t <td>";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "pathType", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 61
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "path", array()), "html", null, true);
            echo "</td>
                                    <td>
                           ";
            // line 63
            if (((isset($context["catcount"]) ? $context["catcount"] : $this->getContext($context, "catcount")) > 0)) {
                // line 64
                echo "                                    ";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["catdata"]) ? $context["catdata"] : $this->getContext($context, "catdata")), (isset($context["mycat"]) ? $context["mycat"] : $this->getContext($context, "mycat")), array(), "array"), "html", null, true);
                echo "
                            ";
            }
            // line 66
            echo "                                    </td>
\t\t\t\t\t\t\t\t\t\t<td>
                             ";
            // line 68
            if (((isset($context["heirchycount"]) ? $context["heirchycount"] : $this->getContext($context, "heirchycount")) > 0)) {
                // line 69
                echo "\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["resourcetype"]) ? $context["resourcetype"] : $this->getContext($context, "resourcetype")), (isset($context["mycat"]) ? $context["mycat"] : $this->getContext($context, "mycat")), array(), "array"), "html", null, true);
                echo "
                               ";
            }
            // line 71
            echo "\t\t\t\t\t\t\t\t\t\t</td>

\t\t\t\t\t\t\t\t\t\t<td>";
            // line 73
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["todo"], "addedDatetime", array()), "d/m/Y"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 74
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["todo"], "modifiedDatetime", array()), "d/m/Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t   <td><a  class=\"confirmation\" href =\"";
            // line 76
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
            echo "admin/resource/delete/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", array()), "html", null, true);
            echo "\"><button class=\"btn btn-danger btn-icon-anim btn-circle\">
                                             <i class=\"icon-trash\"></i>
                                                        </button></a>
                                                        <a href=\"";
            // line 79
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
            echo "admin/resources/edit/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", array()), "html", null, true);
            echo "\">
                                        <button class=\"btn btn-warning btn-icon-anim btn-circle\">
                                         <i class=\"fa fa-pencil\"></i>
                                         </button></a>
                                                        </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t ";
            // line 85
            $context["myVal"] = ((isset($context["myVal"]) ? $context["myVal"] : $this->getContext($context, "myVal")) + 1);
            // line 86
            echo "                                                   ";
            $context["mycat"] = ((isset($context["mycat"]) ? $context["mycat"] : $this->getContext($context, "mycat")) + 1);
            // line 87
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['todo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 88
        echo "\t\t\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- /Row -->

\t\t\t\t ";
        
        $__internal_f09327651e1cdb9d5ca9701ee6b1d6157ab4fee9ecb50d7de27b83cffba40734->leave($__internal_f09327651e1cdb9d5ca9701ee6b1d6157ab4fee9ecb50d7de27b83cffba40734_prof);

    }

    public function getTemplateName()
    {
        return "/admin/resources/allresources.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  195 => 88,  189 => 87,  186 => 86,  184 => 85,  173 => 79,  165 => 76,  160 => 74,  156 => 73,  152 => 71,  146 => 69,  144 => 68,  140 => 66,  134 => 64,  132 => 63,  127 => 61,  123 => 60,  119 => 59,  115 => 58,  112 => 57,  108 => 56,  103 => 55,  101 => 54,  96 => 53,  94 => 52,  56 => 17,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'adminlayout.html.twig' %}
{% block body %}
<div class=\"page-wrapper\">
   <div class=\"container-fluid\">

\t\t\t\t
\t\t\t\t<!-- Row -->
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"panel panel-default card-view\">
\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t\t\t\t<h6 class=\"panel-title txt-dark\">Resources</h6>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t<a href=\"{{ url('homepage') }}admin/resource/createnew\"><button type=\"button\" class=\"btn btn-success\">Create A New </button></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"panel-wrapper collapse in\">
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"table-wrap\">
\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t\t\t\t\t\t\t<table id=\"datable_1\" class=\"table table-hover display  pb-30\" >
\t\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Title</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Type</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Path Url</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Category</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Type 0f Resource(if available)</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Added Date</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified Date</th>
\t\t\t\t\t\t\t\t\t\t\t     <th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t\t\t\t<tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Title</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Type</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Path Url</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Category</th>
\t\t\t\t\t\t\t\t\t\t\t<th>Type 0f Resource(if available)</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Added Date</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified Date</th>
\t\t\t\t\t\t\t\t\t\t\t     <th>Actions</th>\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tbody>
                                                  {% set myVal = 1 %}
                                                   {% set mycat = 0 %} 
                       {% set catcount = catdata | length %}
               {% set heirchycount =  resourcetype | length %}               
                                         {% for todo in alldatas %}
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>{{ myVal }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ todo.title }}</td>
\t\t\t\t\t\t\t\t\t\t <td>{{ todo.pathType }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ todo.path  }}</td>
                                    <td>
                           {% if catcount > 0%}
                                    {{ catdata[mycat] }}
                            {%endif%}
                                    </td>
\t\t\t\t\t\t\t\t\t\t<td>
                             {% if heirchycount > 0%}
\t\t\t\t\t\t\t\t\t\t{{ resourcetype[mycat] }}
                               {%endif%}
\t\t\t\t\t\t\t\t\t\t</td>

\t\t\t\t\t\t\t\t\t\t<td>{{ todo.addedDatetime |date(\"d/m/Y\")  }} </td>
\t\t\t\t\t\t\t\t\t\t<td>{{ todo.modifiedDatetime | date(\"d/m/Y\")  }}</td>
\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t   <td><a  class=\"confirmation\" href =\"{{ url('homepage') }}admin/resource/delete/{{todo.id}}\"><button class=\"btn btn-danger btn-icon-anim btn-circle\">
                                             <i class=\"icon-trash\"></i>
                                                        </button></a>
                                                        <a href=\"{{ url('homepage') }}admin/resources/edit/{{todo.id}}\">
                                        <button class=\"btn btn-warning btn-icon-anim btn-circle\">
                                         <i class=\"fa fa-pencil\"></i>
                                         </button></a>
                                                        </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t {% set myVal = myVal + 1 %}
                                                   {% set mycat = mycat + 1 %}
\t\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- /Row -->

\t\t\t\t {% endblock %}
", "/admin/resources/allresources.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/admin/resources/allresources.html.twig");
    }
}
