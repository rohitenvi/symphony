<?php

/* /admin/category/createcat.html.twig */
class __TwigTemplate_e3abee6cd89afef5ca3ea93839b88f9c5f0f6e982033cc76bef5b9ed084e1041 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("adminlayout.html.twig", "/admin/category/createcat.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "adminlayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_52d6003524642ba5e9b426876dbe44477bcc08328b08407d4428fb100d0fa96f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52d6003524642ba5e9b426876dbe44477bcc08328b08407d4428fb100d0fa96f->enter($__internal_52d6003524642ba5e9b426876dbe44477bcc08328b08407d4428fb100d0fa96f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/admin/category/createcat.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_52d6003524642ba5e9b426876dbe44477bcc08328b08407d4428fb100d0fa96f->leave($__internal_52d6003524642ba5e9b426876dbe44477bcc08328b08407d4428fb100d0fa96f_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_ce529910a35f2dc86a106610cfcd555becc0f1c97babc88fad53995d06b74664 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce529910a35f2dc86a106610cfcd555becc0f1c97babc88fad53995d06b74664->enter($__internal_ce529910a35f2dc86a106610cfcd555becc0f1c97babc88fad53995d06b74664_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"panel panel-default card-view\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Create  A  Category</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"form-wrap\">
 <form action=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/cat/savenew\" method=\"post\" enctype=\"multipart/form-data\">
  <div class=\"form-group\">
    <label for=\"nameofresource\">Title of Category:</label>
    <input type=\"text\" class=\"form-control\" id=\"nameofcatgory\" name=\"categoryname\" required>
  </div>

  <div class=\"form-group\">
  <label for=\"typeofpath\">Path Type:</label>
  <select class=\"form-control\" name=\"parentid\" id=\"catsparent\" required>

  ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["catdatas"]) ? $context["catdatas"] : $this->getContext($context, "catdatas")));
        foreach ($context['_seq'] as $context["key"] => $context["value"]) {
            // line 28
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["value"], "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "   </select>
  </div> 

<button type=\"submit\" class=\"btn btn-default\">Submit</button>
</form> 
</div>
</div></div>
</div>
</div>
</div>
</div>
</div>
  ";
        
        $__internal_ce529910a35f2dc86a106610cfcd555becc0f1c97babc88fad53995d06b74664->leave($__internal_ce529910a35f2dc86a106610cfcd555becc0f1c97babc88fad53995d06b74664_prof);

    }

    public function getTemplateName()
    {
        return "/admin/category/createcat.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 30,  73 => 28,  69 => 27,  56 => 17,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"adminlayout.html.twig\" %}
{% block body %}
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"panel panel-default card-view\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Create  A  Category</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"form-wrap\">
 <form action=\"{{ url('homepage') }}admin/cat/savenew\" method=\"post\" enctype=\"multipart/form-data\">
  <div class=\"form-group\">
    <label for=\"nameofresource\">Title of Category:</label>
    <input type=\"text\" class=\"form-control\" id=\"nameofcatgory\" name=\"categoryname\" required>
  </div>

  <div class=\"form-group\">
  <label for=\"typeofpath\">Path Type:</label>
  <select class=\"form-control\" name=\"parentid\" id=\"catsparent\" required>

  {% for key,value in catdatas %}
  <option value=\"{{ key }}\">{{value}}</option>
  {%endfor%}
   </select>
  </div> 

<button type=\"submit\" class=\"btn btn-default\">Submit</button>
</form> 
</div>
</div></div>
</div>
</div>
</div>
</div>
</div>
  {% endblock %}", "/admin/category/createcat.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/admin/category/createcat.html.twig");
    }
}
