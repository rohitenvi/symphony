<?php

/* frontend/behaviour.html.twig */
class __TwigTemplate_fb5a42920077c79f6b907b2dd8bcc7d008d60a837f860cbd95940a57eb787106 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("home.html.twig", "frontend/behaviour.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "home.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63b71460d42f9cef8208aa9906829576d2a53851280efdc909c97bd386bf4b3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63b71460d42f9cef8208aa9906829576d2a53851280efdc909c97bd386bf4b3c->enter($__internal_63b71460d42f9cef8208aa9906829576d2a53851280efdc909c97bd386bf4b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontend/behaviour.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_63b71460d42f9cef8208aa9906829576d2a53851280efdc909c97bd386bf4b3c->leave($__internal_63b71460d42f9cef8208aa9906829576d2a53851280efdc909c97bd386bf4b3c_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_598988ddee7a0865747d34d5ed6699e4d93f9053e7e88e2dc029482c840924e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_598988ddee7a0865747d34d5ed6699e4d93f9053e7e88e2dc029482c840924e7->enter($__internal_598988ddee7a0865747d34d5ed6699e4d93f9053e7e88e2dc029482c840924e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<section class=\"slider slider-2\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-8 pad-0\">
            <h2>
                <span>Behavioural Science</span>
                <img class=\"hidden visible-xs\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/homegraphic-bc.png"), "html", null, true);
        echo "\" alt=\"mob-home\">
            </h2>
            <p>The Human Behaviour Change Project is a collaboration between world leading institution to create and develop a Machine Learning Programme that can analyse and literature and no more text</p>
             </div>
        </div>
    </div>
</section>
<section class=\"behaviour-diagram\" >
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3 col-sm-3 text-center diagram-visaul\" >
                    <div class=\"icon\">
                    <img src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/i-icon.png"), "html", null, true);
        echo "\" alt=\"team-icon\">
                </div>
                <p>
                    This Diagram is a visualisation of the flow of some to something else to produce an outcome.
                </p>
                <a href=\"\" class=\"btn res-btn\">Explain Diagram</a>
            </div>
            <div class=\"col-md-6 col-sm-6 col-xs-12 text-center outcome-img triangle-part\" >
            <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"shadow-box\">
                <div class=\"inner-tri\">
                    <span class=\"out-come out-top\"><a data-toggle=\"pill\" href=\"#home\"><img class=\"layer\" src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/outcome.png"), "html", null, true);
        echo "\" alt=\"image\"><img class=\"overlay-1\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/outcome-hover.png"), "html", null, true);
        echo "\" alt=\"image\"></a></span>
                </div>
                <div class=\"middle-pic\">
                    <div class=\"inner-tri-ex out-come\">
                        <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu1\"><img class=\"layer\" src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/expourse.png"), "html", null, true);
        echo "\" alt=\"image\">
                        <img class=\"overlay-1\" src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/expourse-hover.png"), "html", null, true);
        echo "\" alt=\"image\">
                        </a></span>
                    </div>
                    <div class=\"inner-tri-context out-come\">
                        <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu2\"><img class=\"layer\" src=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/context.png"), "html", null, true);
        echo "\" alt=\"image\">
                            <img class=\"overlay-1\" src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/context-hover.png"), "html", null, true);
        echo "\" alt=\"image\">
                        </a></span>
                    </div>
                </div>
                    <div class=\"bottom-pic\">
                        <div class=\"inner-tri-inter out-come\">
                            <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu3\"><img class=\"layer\" src=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/interv.png"), "html", null, true);
        echo "\" alt=\"image\">
                                <img class=\"overlay-1\" src=\"";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/interv-hover.png"), "html", null, true);
        echo "\" alt=\"image\">
                            </a></span>
                        </div>
                        <div class=\"inner-tri-mech out-come\">
                            <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu4\"><img class=\"layer\" src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/machine.png"), "html", null, true);
        echo "\" alt=\"image\">
                                <img class=\"overlay-1\" src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/machine-hover.png"), "html", null, true);
        echo "\" alt=\"image\">
                            </a></span>
                        </div>
                        <div class=\"inner-tri-beh out-come\">
                            <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu5\"><img class=\"layer\" src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/behaviour.png"), "html", null, true);
        echo "\" alt=\"image\">
                            <img class=\"overlay-1\" src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/behaviour-hover.png"), "html", null, true);
        echo "\" alt=\"image\">
                            </a></span>
                        </div>
                    </div>
                </div>


            </div>

        </div>
        <!-- <p class=\"arrow-up\">
                    Select a section of the Diagram for an explanation and to show associated resources
                </p> -->
            </div>
              <div class=\"col-md-3 col-sm-3 text-center explain-button\">
                 <p>What to know more about this diagram?</p>
                  <a href=\"\" class=\"btn\"><img src=\"";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/arrow-back-white.svg"), "html", null, true);
        echo "\">Explain Diagram</a>
            </div>
        </div>
    </div>
</section>
         <div class=\"tab-content\" >
    <div id=\"home\" class=\"tab-pane fade in active\">
        <div class=\"\">
        <div class=\"col-md-6 col-md-offset-3 text-center\"> <p class=\"arrow-up\">
                    Select a section of the Diagram for an explanation and to show associated resources
                </p>
            </div>
        </div>
    </div>
    <div id=\"menu1\" class=\"tab-pane fade\">
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3 text-style text-center\">           
                      <h3>Exposure</h3>
                <p class=\"qoutes\">
                    Exposure is defined and consists of reach (how far it reaches) and engagement (how engaged something is) 
                    Reach Engagement 
                </p>
            </div>
        </div>
        <section class=\"reach-section text-center\">
    <div id=\"exTab2\" class=\"\">
        <div class=\"\">
            
               


 
<ul class=\"nav nav-tabs behaviour-tab\">
            <li class=\"active\">
        <a  href=\"#1\" data-toggle=\"tab\">Reach</a>
            </li>
            <li><a href=\"#2\" data-toggle=\"tab\">Engagement</a>
            </li>
            
        </ul>

            <div class=\"tab-content \">
              <div class=\"tab-pane active\" id=\"1\">
                    <div class=\"\">
  <div class=\"accordion-option\">
    
    <a href=\"javascript:void(0)\" class=\"toggle-accordion active\" accordion-id=\"#accordion\"></a>
  </div>
  <div class=\"clearfix\"></div>
  <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\" aria-expanded=\"true\" aria-controls=\"collapseOne\">
          General
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseOne\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\">
          Addtional Bibliography 
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseTwo\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
       <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingThree\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree\" aria-expanded=\"true\" aria-controls=\"collapseThree\">
         Presentations
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseThree\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingThree\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
  </div>
</div>
                </div>
                         <div class=\"tab-pane\" id=\"2\">
                    <div class=\"\">
  <div class=\"accordion-option\">
    
    <a href=\"javascript:void(0)\" class=\"toggle-accordion active\" accordion-id=\"#accordion\"></a>
  </div>
  <div class=\"clearfix\"></div>
  <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\" aria-expanded=\"true\" aria-controls=\"collapseOne\">
          General
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseOne\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
          <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\">
          Addtional Bibliography 
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseTwo\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
       <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingThree\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree\" aria-expanded=\"true\" aria-controls=\"collapseThree\">
         Presentations
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseThree\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingThree\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
  </div>
</div>
                </div>
      
  </div>




<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->


        </div>
    </div>
</section>
    </div>
    <div id=\"menu2\" class=\"tab-pane fade\">
      <h3>Menu 2</h3>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
    </div>
    <div id=\"menu3\" class=\"tab-pane fade\">
      <h3>Menu 3</h3>
      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
    <div id=\"menu4\" class=\"tab-pane fade\">
      <h3>Menu 4</h3>
      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
    <div id=\"menu5\" class=\"tab-pane fade\">
      <section class=\"reach-section text-center\">
    <div id=\"exTab2\" class=\"\">
        <div class=\"text-style\">
            <div class=\"row\">
        <div class=\"col-md-6 col-md-offset-3 text-center\">
               
     <h3>Target Behaviour</h3>
                <p class=\"qoutes\">
                    Target Behaviour is defined and consists of reach (how far it reaches) and engagement (how engaged something is) 
Reach Engagement 
                </p>
            </div>
        </div>

 
<!-- <ul class=\"nav nav-tabs behaviour-tab\">
            <li class=\"active\">
        <a  href=\"#1\" data-toggle=\"tab\">Reach</a>
            </li>
            <li><a href=\"#2\" data-toggle=\"tab\">Engagement</a>
            </li>
            
        </ul> -->
        <hr>

            <div class=\"tab-content \">
              <div class=\"tab-pane active\" id=\"1\">
                    <div class=\"\">
  <div class=\"accordion-option\">
    
    <a href=\"javascript:void(0)\" class=\"toggle-accordion active\" accordion-id=\"#accordion\"></a>
  </div>
  <div class=\"clearfix\"></div>
  <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingOne1\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne1\" aria-expanded=\"true\" aria-controls=\"collapseOne1\">
          General
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseOne1\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne1\">
          <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo1\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo1\" aria-expanded=\"true\" aria-controls=\"collapseTwo1\">
          Addtional Bibliography 
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseTwo1\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
        <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingThree1\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree1\" aria-expanded=\"true\" aria-controls=\"collapseThree1\">
         Presentations
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseThree1\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingThree1\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
  </div>
</div>
                </div>
          <div class=\"tab-pane\" id=\"2\">
          <h3>Notice the gap between the content and tab after applying a background color</h3>
         </div>
      
    </div>
    </div>
    </div>
    </section>
    </div>
    </div>
    ";
        
        $__internal_598988ddee7a0865747d34d5ed6699e4d93f9053e7e88e2dc029482c840924e7->leave($__internal_598988ddee7a0865747d34d5ed6699e4d93f9053e7e88e2dc029482c840924e7_prof);

    }

    public function getTemplateName()
    {
        return "frontend/behaviour.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  156 => 76,  137 => 60,  133 => 59,  126 => 55,  122 => 54,  115 => 50,  111 => 49,  102 => 43,  98 => 42,  91 => 38,  87 => 37,  78 => 33,  63 => 21,  48 => 9,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'home.html.twig' %}
{% block body %}
<section class=\"slider slider-2\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-8 pad-0\">
            <h2>
                <span>Behavioural Science</span>
                <img class=\"hidden visible-xs\" src=\"{{ asset('vendors/frontend/images/homegraphic-bc.png') }}\" alt=\"mob-home\">
            </h2>
            <p>The Human Behaviour Change Project is a collaboration between world leading institution to create and develop a Machine Learning Programme that can analyse and literature and no more text</p>
             </div>
        </div>
    </div>
</section>
<section class=\"behaviour-diagram\" >
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3 col-sm-3 text-center diagram-visaul\" >
                    <div class=\"icon\">
                    <img src=\"{{ asset('vendors/frontend/images/i-icon.png') }}\" alt=\"team-icon\">
                </div>
                <p>
                    This Diagram is a visualisation of the flow of some to something else to produce an outcome.
                </p>
                <a href=\"\" class=\"btn res-btn\">Explain Diagram</a>
            </div>
            <div class=\"col-md-6 col-sm-6 col-xs-12 text-center outcome-img triangle-part\" >
            <div class=\"row\">
            <div class=\"col-md-12\">
                <div class=\"shadow-box\">
                <div class=\"inner-tri\">
                    <span class=\"out-come out-top\"><a data-toggle=\"pill\" href=\"#home\"><img class=\"layer\" src=\"{{ asset('vendors/frontend/images/outcome.png') }}\" alt=\"image\"><img class=\"overlay-1\" src=\"{{ asset('vendors/frontend/images/outcome-hover.png') }}\" alt=\"image\"></a></span>
                </div>
                <div class=\"middle-pic\">
                    <div class=\"inner-tri-ex out-come\">
                        <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu1\"><img class=\"layer\" src=\"{{ asset('vendors/frontend/images/expourse.png') }}\" alt=\"image\">
                        <img class=\"overlay-1\" src=\"{{ asset('vendors/frontend/images/expourse-hover.png') }}\" alt=\"image\">
                        </a></span>
                    </div>
                    <div class=\"inner-tri-context out-come\">
                        <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu2\"><img class=\"layer\" src=\"{{ asset('vendors/frontend/images/context.png') }}\" alt=\"image\">
                            <img class=\"overlay-1\" src=\"{{ asset('vendors/frontend/images/context-hover.png') }}\" alt=\"image\">
                        </a></span>
                    </div>
                </div>
                    <div class=\"bottom-pic\">
                        <div class=\"inner-tri-inter out-come\">
                            <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu3\"><img class=\"layer\" src=\"{{ asset('vendors/frontend/images/interv.png') }}\" alt=\"image\">
                                <img class=\"overlay-1\" src=\"{{ asset('vendors/frontend/images/interv-hover.png') }}\" alt=\"image\">
                            </a></span>
                        </div>
                        <div class=\"inner-tri-mech out-come\">
                            <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu4\"><img class=\"layer\" src=\"{{ asset('vendors/frontend/images/machine.png') }}\" alt=\"image\">
                                <img class=\"overlay-1\" src=\"{{ asset('vendors/frontend/images/machine-hover.png') }}\" alt=\"image\">
                            </a></span>
                        </div>
                        <div class=\"inner-tri-beh out-come\">
                            <span class=\"ex-porse\"><a data-toggle=\"pill\" href=\"#menu5\"><img class=\"layer\" src=\"{{ asset('vendors/frontend/images/behaviour.png') }}\" alt=\"image\">
                            <img class=\"overlay-1\" src=\"{{ asset('vendors/frontend/images/behaviour-hover.png') }}\" alt=\"image\">
                            </a></span>
                        </div>
                    </div>
                </div>


            </div>

        </div>
        <!-- <p class=\"arrow-up\">
                    Select a section of the Diagram for an explanation and to show associated resources
                </p> -->
            </div>
              <div class=\"col-md-3 col-sm-3 text-center explain-button\">
                 <p>What to know more about this diagram?</p>
                  <a href=\"\" class=\"btn\"><img src=\"{{ asset('vendors/frontend/images/arrow-back-white.svg') }}\">Explain Diagram</a>
            </div>
        </div>
    </div>
</section>
         <div class=\"tab-content\" >
    <div id=\"home\" class=\"tab-pane fade in active\">
        <div class=\"\">
        <div class=\"col-md-6 col-md-offset-3 text-center\"> <p class=\"arrow-up\">
                    Select a section of the Diagram for an explanation and to show associated resources
                </p>
            </div>
        </div>
    </div>
    <div id=\"menu1\" class=\"tab-pane fade\">
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3 text-style text-center\">           
                      <h3>Exposure</h3>
                <p class=\"qoutes\">
                    Exposure is defined and consists of reach (how far it reaches) and engagement (how engaged something is) 
                    Reach Engagement 
                </p>
            </div>
        </div>
        <section class=\"reach-section text-center\">
    <div id=\"exTab2\" class=\"\">
        <div class=\"\">
            
               


 
<ul class=\"nav nav-tabs behaviour-tab\">
            <li class=\"active\">
        <a  href=\"#1\" data-toggle=\"tab\">Reach</a>
            </li>
            <li><a href=\"#2\" data-toggle=\"tab\">Engagement</a>
            </li>
            
        </ul>

            <div class=\"tab-content \">
              <div class=\"tab-pane active\" id=\"1\">
                    <div class=\"\">
  <div class=\"accordion-option\">
    
    <a href=\"javascript:void(0)\" class=\"toggle-accordion active\" accordion-id=\"#accordion\"></a>
  </div>
  <div class=\"clearfix\"></div>
  <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\" aria-expanded=\"true\" aria-controls=\"collapseOne\">
          General
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseOne\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\">
          Addtional Bibliography 
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseTwo\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
       <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingThree\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree\" aria-expanded=\"true\" aria-controls=\"collapseThree\">
         Presentations
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseThree\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingThree\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
  </div>
</div>
                </div>
                         <div class=\"tab-pane\" id=\"2\">
                    <div class=\"\">
  <div class=\"accordion-option\">
    
    <a href=\"javascript:void(0)\" class=\"toggle-accordion active\" accordion-id=\"#accordion\"></a>
  </div>
  <div class=\"clearfix\"></div>
  <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\" aria-expanded=\"true\" aria-controls=\"collapseOne\">
          General
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseOne\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
          <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\">
          Addtional Bibliography 
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseTwo\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
       <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingThree\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree\" aria-expanded=\"true\" aria-controls=\"collapseThree\">
         Presentations
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseThree\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingThree\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
  </div>
</div>
                </div>
      
  </div>




<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->


        </div>
    </div>
</section>
    </div>
    <div id=\"menu2\" class=\"tab-pane fade\">
      <h3>Menu 2</h3>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
    </div>
    <div id=\"menu3\" class=\"tab-pane fade\">
      <h3>Menu 3</h3>
      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
    <div id=\"menu4\" class=\"tab-pane fade\">
      <h3>Menu 4</h3>
      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
    <div id=\"menu5\" class=\"tab-pane fade\">
      <section class=\"reach-section text-center\">
    <div id=\"exTab2\" class=\"\">
        <div class=\"text-style\">
            <div class=\"row\">
        <div class=\"col-md-6 col-md-offset-3 text-center\">
               
     <h3>Target Behaviour</h3>
                <p class=\"qoutes\">
                    Target Behaviour is defined and consists of reach (how far it reaches) and engagement (how engaged something is) 
Reach Engagement 
                </p>
            </div>
        </div>

 
<!-- <ul class=\"nav nav-tabs behaviour-tab\">
            <li class=\"active\">
        <a  href=\"#1\" data-toggle=\"tab\">Reach</a>
            </li>
            <li><a href=\"#2\" data-toggle=\"tab\">Engagement</a>
            </li>
            
        </ul> -->
        <hr>

            <div class=\"tab-content \">
              <div class=\"tab-pane active\" id=\"1\">
                    <div class=\"\">
  <div class=\"accordion-option\">
    
    <a href=\"javascript:void(0)\" class=\"toggle-accordion active\" accordion-id=\"#accordion\"></a>
  </div>
  <div class=\"clearfix\"></div>
  <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingOne1\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne1\" aria-expanded=\"true\" aria-controls=\"collapseOne1\">
          General
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseOne1\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne1\">
          <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo1\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo1\" aria-expanded=\"true\" aria-controls=\"collapseTwo1\">
          Addtional Bibliography 
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseTwo1\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
        <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
    <div class=\"panel panel-default\">
      <div class=\"panel-heading\" role=\"tab\" id=\"headingThree1\">
        <div class=\"container\">
        <h3 class=\"panel-title\">
        <a role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree1\" aria-expanded=\"true\" aria-controls=\"collapseThree1\">
         Presentations
        </a>
      </h3>
  </div>
      </div>
      <div id=\"collapseThree1\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingThree1\">
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">A link to some sort of resource like powerpoint slide or paper<a class=\"link-text\">PDF</a></span><span class=\"btn-download\"><a href=\"#\">Download</a></span> </div>
        </div>
         <div class=\"panel-body\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">HBCP Tool</a></span><span class=\"btn-download\"><a href=\"#\">Open Tool</a></span> </div>
        </div>
         <div class=\"panel-body light\">
             <div class=\"container\">
          <span class=\"text-download\">Matrix Tool or example of another link Website<a class=\"link-text\">Website</a></span><span class=\"btn-download\"><a href=\"#\">View</a></span> </div>
        </div>
      </div>
    </div>
  </div>
</div>
                </div>
          <div class=\"tab-pane\" id=\"2\">
          <h3>Notice the gap between the content and tab after applying a background color</h3>
         </div>
      
    </div>
    </div>
    </div>
    </section>
    </div>
    </div>
    {% endblock %}", "frontend/behaviour.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/frontend/behaviour.html.twig");
    }
}
