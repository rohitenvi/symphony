<?php

/* /admin/resources/editresources.html.twig */
class __TwigTemplate_724897c9c9d9657a85dc09d8b4c8dc231ada49e0a71e46728312a04650e5cf52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("adminlayout.html.twig", "/admin/resources/editresources.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "adminlayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_96cefa8ddea50f01665b5509aace23f7ec92026ee06b2993b012bc2ef495c25e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96cefa8ddea50f01665b5509aace23f7ec92026ee06b2993b012bc2ef495c25e->enter($__internal_96cefa8ddea50f01665b5509aace23f7ec92026ee06b2993b012bc2ef495c25e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/admin/resources/editresources.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_96cefa8ddea50f01665b5509aace23f7ec92026ee06b2993b012bc2ef495c25e->leave($__internal_96cefa8ddea50f01665b5509aace23f7ec92026ee06b2993b012bc2ef495c25e_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_0ebb3c20b93badd146c2cd2c6d87dacc9be32fe506e8dbdfe71f61f2f023139d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ebb3c20b93badd146c2cd2c6d87dacc9be32fe506e8dbdfe71f61f2f023139d->enter($__internal_0ebb3c20b93badd146c2cd2c6d87dacc9be32fe506e8dbdfe71f61f2f023139d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"panel panel-default card-view\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Create  A  News</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"form-wrap\">
";
        // line 17
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "urlinvalid"), "method")) {
            // line 18
            echo "        <div class=\"alert alert-danger fade in\" role=\"alert\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
            ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "urlinvalid"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 21
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 23
            echo "        </div>
    ";
        }
        // line 25
        echo " <form action=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "uri", array()), "html", null, true);
        echo "\" method=\"post\" enctype=\"multipart/form-data\">
  <div class=\"form-group\">
    <label for=\"nameofresource\">Title of Resource:</label>
    <input type=\"text\" class=\"form-control\" id=\"nameofresource\" name=\"resourcename\" value=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "title", array()), "html", null, true);
        echo "\" required>
  </div>
  <div class=\"form-group\">
  <label for=\"typeofpath\">Link Type:</label>
  <select class=\"form-control\" name=\"pathtype\" id=\"typeofpath\" required>
  <option value=\"\">--Please Select Link Type--</option>
    <option value=\"dropbox\" ";
        // line 34
        if (($this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "pathType", array()) == "dropbox")) {
            echo " selected = \"selected\" ";
        }
        echo " >DropBox</option>
    <option value=\"website\" ";
        // line 35
        if (($this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "pathType", array()) == "website")) {
            echo " selected = \"selected\" ";
        }
        echo ">Website</option>
     <option value=\"tool\" ";
        // line 36
        if (($this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "pathType", array()) == "tool")) {
            echo " selected = \"selected\" ";
        }
        echo ">Tool</option>
   </select>
  </div> 

 <div class=\"form-group catype\" style=\"";
        // line 40
        if (($this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "pathType", array()) == "dropbox")) {
            echo "display:block; ";
        } else {
            echo " display:none; ";
        }
        echo "  \">
  <label for=\"resourcetype\">Resourcetype:</label>
  <select class=\"form-control\" name=\"resourcetype\" id=\"resourcetype\" required=\"required\">
  ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resourcetypes"]) ? $context["resourcetypes"] : $this->getContext($context, "resourcetypes")));
        foreach ($context['_seq'] as $context["_key"] => $context["restype"]) {
            // line 44
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["restype"], "id", array()), "html", null, true);
            echo " \" ";
            if (($this->getAttribute($context["restype"], "id", array()) == $this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "resourceType", array()))) {
                echo " selected = \"selected\"  ";
            }
            echo " >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["restype"], "name", array()), "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['restype'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 46
        echo "   </select>
  </div>

  <div class=\"form-group\" >
  <label for=\"resourcetype\">Link:</label>
 <input type=\"textarea\" name=\"dropboxurl\" class=\"form-control\" value=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "path", array()), "html", null, true);
        echo "\" required/>

  </div>

   <div class=\"form-group\">
  <label for=\"topcatedit\">Main Category:</label>
  <select class=\"form-control\" id=\"topcatedit\"  name=\"topcategoryid\">
  ";
        // line 58
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resourcecategory"]) ? $context["resourcecategory"] : $this->getContext($context, "resourcecategory")));
        foreach ($context['_seq'] as $context["keys"] => $context["cats"]) {
            // line 59
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $context["keys"], "html", null, true);
            echo "\" ";
            if (($context["keys"] == $this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "categoryid", array()))) {
                echo " selected=\"selected\"
  ";
            }
            // line 60
            echo ">";
            echo twig_escape_filter($this->env, $context["cats"], "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['keys'], $context['cats'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "   </select>
  </div>

 

  <div class=\"form-group\">
  <label for=\"unlockcatedit\">Sub Categories:</label>
  <select class=\"form-control\" id=\"unlockcatedit\" name=\"catname\"  required>
  ";
        // line 70
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resourceunlockeds"]) ? $context["resourceunlockeds"] : $this->getContext($context, "resourceunlockeds")));
        foreach ($context['_seq'] as $context["_key"] => $context["resourceunlocked"]) {
            // line 71
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resourceunlocked"], "id", array()), "html", null, true);
            echo "\" toparent=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resourceunlocked"], "parentId", array()), "html", null, true);
            echo "\"  ";
            if (($this->getAttribute($context["resourceunlocked"], "id", array()) == $this->getAttribute((isset($context["resourcedata"]) ? $context["resourcedata"] : $this->getContext($context, "resourcedata")), "category", array()))) {
                echo " selected=\"selected\" style=\"display:block;\" ";
            } else {
                echo " style=\"display:none\"; ";
            }
            echo "          >";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resourceunlocked"], "name", array()), "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resourceunlocked'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "   </select>
  </div>

<button type=\"submit\" class=\"btn btn-default\">Submit</button>
</form> 
</div>
</div></div>
</div>
</div>
</div>
</div>
</div>
  ";
        
        $__internal_0ebb3c20b93badd146c2cd2c6d87dacc9be32fe506e8dbdfe71f61f2f023139d->leave($__internal_0ebb3c20b93badd146c2cd2c6d87dacc9be32fe506e8dbdfe71f61f2f023139d_prof);

    }

    public function getTemplateName()
    {
        return "/admin/resources/editresources.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 73,  197 => 71,  193 => 70,  183 => 62,  174 => 60,  166 => 59,  162 => 58,  152 => 51,  145 => 46,  130 => 44,  126 => 43,  116 => 40,  107 => 36,  101 => 35,  95 => 34,  86 => 28,  79 => 25,  75 => 23,  66 => 21,  62 => 20,  58 => 18,  56 => 17,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"adminlayout.html.twig\" %}
{% block body %}
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"panel panel-default card-view\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Create  A  News</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"form-wrap\">
{% if app.session.flashBag.has('urlinvalid') %}
        <div class=\"alert alert-danger fade in\" role=\"alert\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
            {% for msg in app.session.flashBag.get('urlinvalid') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}
 <form action=\"{{ app.request.uri }}\" method=\"post\" enctype=\"multipart/form-data\">
  <div class=\"form-group\">
    <label for=\"nameofresource\">Title of Resource:</label>
    <input type=\"text\" class=\"form-control\" id=\"nameofresource\" name=\"resourcename\" value=\"{{resourcedata.title}}\" required>
  </div>
  <div class=\"form-group\">
  <label for=\"typeofpath\">Link Type:</label>
  <select class=\"form-control\" name=\"pathtype\" id=\"typeofpath\" required>
  <option value=\"\">--Please Select Link Type--</option>
    <option value=\"dropbox\" {% if resourcedata.pathType == 'dropbox' %} selected = \"selected\" {% endif %} >DropBox</option>
    <option value=\"website\" {% if resourcedata.pathType == 'website' %} selected = \"selected\" {% endif %}>Website</option>
     <option value=\"tool\" {% if resourcedata.pathType == 'tool' %} selected = \"selected\" {% endif %}>Tool</option>
   </select>
  </div> 

 <div class=\"form-group catype\" style=\"{% if resourcedata.pathType == 'dropbox' %}display:block; {%else%} display:none; {%endif%}  \">
  <label for=\"resourcetype\">Resourcetype:</label>
  <select class=\"form-control\" name=\"resourcetype\" id=\"resourcetype\" required=\"required\">
  {%for  restype in resourcetypes %}
  <option value=\"{{ restype.id }} \" {% if restype.id == resourcedata.resourceType %} selected = \"selected\"  {% endif %} >{{ restype.name}}</option>
  {% endfor %}
   </select>
  </div>

  <div class=\"form-group\" >
  <label for=\"resourcetype\">Link:</label>
 <input type=\"textarea\" name=\"dropboxurl\" class=\"form-control\" value=\"{{ resourcedata.path }}\" required/>

  </div>

   <div class=\"form-group\">
  <label for=\"topcatedit\">Main Category:</label>
  <select class=\"form-control\" id=\"topcatedit\"  name=\"topcategoryid\">
  {%for  keys,cats in resourcecategory %}
  <option value=\"{{ keys }}\" {% if keys == resourcedata.categoryid %} selected=\"selected\"
  {%endif%}>{{ cats }}</option>
  {% endfor %}
   </select>
  </div>

 

  <div class=\"form-group\">
  <label for=\"unlockcatedit\">Sub Categories:</label>
  <select class=\"form-control\" id=\"unlockcatedit\" name=\"catname\"  required>
  {%for  resourceunlocked in resourceunlockeds %}
  <option value=\"{{ resourceunlocked.id }}\" toparent=\"{{resourceunlocked.parentId }}\"  {% if resourceunlocked.id == resourcedata.category %} selected=\"selected\" style=\"display:block;\" {%else%} style=\"display:none\"; {%endif%}          >{{ resourceunlocked.name }}</option>
  {% endfor %}
   </select>
  </div>

<button type=\"submit\" class=\"btn btn-default\">Submit</button>
</form> 
</div>
</div></div>
</div>
</div>
</div>
</div>
</div>
  {% endblock %}", "/admin/resources/editresources.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/admin/resources/editresources.html.twig");
    }
}
