<?php

/* /admin/category/allcats.html.twig */
class __TwigTemplate_63df55f50d1a36c64227b3ff2af93730d3c07bffe6439381edfddc9780bb3e11 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("adminlayout.html.twig", "/admin/category/allcats.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "adminlayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7e6feddbf25a3dce91babc207421c0ca8ef50841b7901e557b61ba1ec888c88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7e6feddbf25a3dce91babc207421c0ca8ef50841b7901e557b61ba1ec888c88->enter($__internal_c7e6feddbf25a3dce91babc207421c0ca8ef50841b7901e557b61ba1ec888c88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/admin/category/allcats.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c7e6feddbf25a3dce91babc207421c0ca8ef50841b7901e557b61ba1ec888c88->leave($__internal_c7e6feddbf25a3dce91babc207421c0ca8ef50841b7901e557b61ba1ec888c88_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_29cdd9d2c2f1132bbe9552807da91fafbd1ba53fc5b0d540be2ce8c24d3670aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29cdd9d2c2f1132bbe9552807da91fafbd1ba53fc5b0d540be2ce8c24d3670aa->enter($__internal_29cdd9d2c2f1132bbe9552807da91fafbd1ba53fc5b0d540be2ce8c24d3670aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"page-wrapper\">
   <div class=\"container-fluid\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"panel panel-default card-view\">
\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t\t\t\t<h6 class=\"panel-title txt-dark\">Category</h6>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/cat/create\"><button type=\"button\" class=\"btn btn-success\">Create a Category </button></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"panel-wrapper collapse in\">
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"table-wrap\">
\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t\t\t\t\t\t\t<table id=\"datable_1\" class=\"table table-hover display  pb-30\" >
\t\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t    <th>Category Name</th>
\t\t\t\t\t\t\t\t\t    <th>Parent Category</th>
\t\t\t\t\t\t\t\t\t\t<th>Created</th>
\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t\t<tfoot>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t<th>Category Name</th>
\t\t\t\t\t\t\t\t\t\t<th>Parent Category</th>
\t\t\t\t\t\t\t\t\t      <th>Created</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t    \t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tbody>
                                                  ";
        // line 44
        $context["myVal"] = 1;
        // line 45
        echo "                                                  ";
        $context["mycat"] = 0;
        // line 46
        echo "                           ";
        $context["catcount"] = twig_length_filter($this->env, (isset($context["topcats"]) ? $context["topcats"] : $this->getContext($context, "topcats")));
        // line 47
        echo "                           ";
        $context["heirchycount"] = twig_length_filter($this->env, (isset($context["catsheirchy"]) ? $context["catsheirchy"] : $this->getContext($context, "catsheirchy")));
        // line 48
        echo "                                        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["catdatas"]) ? $context["catdatas"] : $this->getContext($context, "catdatas")));
        foreach ($context['_seq'] as $context["_key"] => $context["catdata"]) {
            // line 49
            echo "\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 50
            echo twig_escape_filter($this->env, (isset($context["myVal"]) ? $context["myVal"] : $this->getContext($context, "myVal")), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["catdata"], "name", array()), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t<td>
                                        ";
            // line 54
            if (((isset($context["catcount"]) ? $context["catcount"] : $this->getContext($context, "catcount")) > 0)) {
                // line 55
                echo "\t\t\t\t\t\t\t\t\t\t";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["topcats"]) ? $context["topcats"] : $this->getContext($context, "topcats")), (isset($context["mycat"]) ? $context["mycat"] : $this->getContext($context, "mycat")), array(), "array"), "html", null, true);
                echo "  ";
            }
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 56
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["catdata"], "createdTime", array()), "d/m/Y"), "html", null, true);
            echo " </td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 57
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["catdata"], "updatedTime", array()), "d/m/Y"), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td><a class=\"confirmation\" href =\"";
            // line 58
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
            echo "admin/cat/delete/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["catdata"], "id", array()), "html", null, true);
            echo "\"><button class=\"btn btn-danger btn-icon-anim btn-circle\">
                                             <i class=\"icon-trash\"></i>
                                                        </button></a>
                                                        <a href=\"";
            // line 61
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
            echo "admin/cat/edit/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["catdata"], "id", array()), "html", null, true);
            echo "\">
                                        <button class=\"btn btn-warning btn-icon-anim btn-circle\">
                                         <i class=\"fa fa-pencil\"></i>
                                         </button></a>
                                                        </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t ";
            // line 67
            $context["myVal"] = ((isset($context["myVal"]) ? $context["myVal"] : $this->getContext($context, "myVal")) + 1);
            // line 68
            echo "                                                     ";
            $context["mycat"] = ((isset($context["mycat"]) ? $context["mycat"] : $this->getContext($context, "mycat")) + 1);
            // line 69
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['catdata'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "\t\t\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- /Row -->
\t\t\t\t ";
        
        $__internal_29cdd9d2c2f1132bbe9552807da91fafbd1ba53fc5b0d540be2ce8c24d3670aa->leave($__internal_29cdd9d2c2f1132bbe9552807da91fafbd1ba53fc5b0d540be2ce8c24d3670aa_prof);

    }

    public function getTemplateName()
    {
        return "/admin/category/allcats.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 71,  156 => 69,  153 => 68,  151 => 67,  140 => 61,  132 => 58,  128 => 57,  124 => 56,  117 => 55,  115 => 54,  109 => 51,  105 => 50,  102 => 49,  97 => 48,  94 => 47,  91 => 46,  88 => 45,  86 => 44,  53 => 14,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'adminlayout.html.twig' %}
{% block body %}
<div class=\"page-wrapper\">
   <div class=\"container-fluid\">
\t\t\t\t<div class=\"row\">
\t\t\t\t\t<div class=\"col-sm-12\">
\t\t\t\t\t\t<div class=\"panel panel-default card-view\">
\t\t\t\t\t\t\t<div class=\"panel-heading\">
\t\t\t\t\t\t\t\t<div class=\"pull-left\">
\t\t\t\t\t\t\t\t\t<h6 class=\"panel-title txt-dark\">Category</h6>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"pull-right\">
\t\t\t\t\t\t\t\t\t<a href=\"{{ url('homepage') }}admin/cat/create\"><button type=\"button\" class=\"btn btn-success\">Create a Category </button></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"clearfix\"></div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"panel-wrapper collapse in\">
\t\t\t\t\t\t\t\t<div class=\"panel-body\">
\t\t\t\t\t\t\t\t\t<div class=\"table-wrap\">
\t\t\t\t\t\t\t\t\t\t<div class=\"table-responsive\">
\t\t\t\t\t\t\t\t\t\t\t<table id=\"datable_1\" class=\"table table-hover display  pb-30\" >
\t\t\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t    <th>Category Name</th>
\t\t\t\t\t\t\t\t\t    <th>Parent Category</th>
\t\t\t\t\t\t\t\t\t\t<th>Created</th>
\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t\t\t<tfoot>
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>S.No</th>
\t\t\t\t\t\t\t\t\t\t<th>Category Name</th>
\t\t\t\t\t\t\t\t\t\t<th>Parent Category</th>
\t\t\t\t\t\t\t\t\t      <th>Created</th>
\t\t\t\t\t\t\t\t\t\t\t\t<th>Modified</th>
\t\t\t\t\t\t    \t\t\t\t\t<th>Actions</th>
\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t</tfoot>
\t\t\t\t\t\t\t\t\t\t\t\t<tbody>
                                                  {% set myVal = 1 %}
                                                  {% set mycat = 0 %}
                           {% set catcount = topcats | length %}
                           {% set heirchycount =  catsheirchy| length  %}
                                        {% for catdata in catdatas %}
\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<td>{{ myVal }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ catdata.name }}</td>
\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t<td>
                                        {% if catcount > 0%}
\t\t\t\t\t\t\t\t\t\t{{ topcats[mycat] }}  {%endif%}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ catdata.createdTime |date(\"d/m/Y\") }} </td>
\t\t\t\t\t\t\t\t\t\t<td>{{ catdata.updatedTime | date(\"d/m/Y\")  }}</td>
\t\t\t\t\t\t\t\t\t\t<td><a class=\"confirmation\" href =\"{{ url('homepage') }}admin/cat/delete/{{catdata.id}}\"><button class=\"btn btn-danger btn-icon-anim btn-circle\">
                                             <i class=\"icon-trash\"></i>
                                                        </button></a>
                                                        <a href=\"{{ url('homepage') }}admin/cat/edit/{{catdata.id}}\">
                                        <button class=\"btn btn-warning btn-icon-anim btn-circle\">
                                         <i class=\"fa fa-pencil\"></i>
                                         </button></a>
                                                        </td>
\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t\t\t {% set myVal = myVal + 1 %}
                                                     {% set mycat = mycat + 1 %}

\t\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>\t
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<!-- /Row -->
\t\t\t\t {% endblock %}", "/admin/category/allcats.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/admin/category/allcats.html.twig");
    }
}
