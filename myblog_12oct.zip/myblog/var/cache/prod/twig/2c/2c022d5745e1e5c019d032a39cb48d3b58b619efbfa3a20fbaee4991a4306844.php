<?php

/* home.html.twig */
class __TwigTemplate_0e465e4615dda8af659d17f7066f8be883f45c0ba5d448b4e0a805bc48fa4fb5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2885ecd57d0e6c96de9183b29aef914618780035e2ecc092dc806ce4bb134f35 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2885ecd57d0e6c96de9183b29aef914618780035e2ecc092dc806ce4bb134f35->enter($__internal_2885ecd57d0e6c96de9183b29aef914618780035e2ecc092dc806ce4bb134f35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "home.html.twig"));

        // line 1
        echo "<!doctype html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <!-- TITLE OF SITE -->
    <title>Homepage</title>
\t<meta name=\"description\" content=\"\" />
    <meta name=\"keywords\" content=\"\" />
    <meta name=\"author\" content=\"\">
    <link href=\"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/css/bootstrap.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/css/bootstrap-select.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/css/custom.css"), "html", null, true);
        echo " \">
    <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/css/bootstrap-select.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/css/responsive.css"), "html", null, true);
        echo "\">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
</head>
<body>
<header class=\"header\">       
    <nav class=\"index-header navbar \" id=\"main-navbar\">
        <div class=\"container\">
            <!-- Menu Button for Mobile Devices -->
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#navbar-collapse\">
                    <ul class=\"list-inline\">
                        <li><img src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/mob-menu.svg"), "html", null, true);
        echo "\" class=\"\" alt=\"mob-menu\">
                          
                        </li>
                        <li><span class=\"\">Menu</span></li>
                    </ul>
                </button>
                <a href=\"";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "\" class=\"navbar-brand smooth-scroll\">
                \t<img src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/logo.svg"), "html", null, true);
        echo "\" class=\"logo_height\" alt=\"logo\"/>
                </a>
            </div><!-- /End Navbar Header -->
            <div class=\"collapse navbar-collapse\" id=\"navbar-collapse\">
                <!-- Menu Links -->
                   <ul class=\"nav navbar-nav navbar-right\">
                    <li class=\"active\"><a href=\"";
        // line 50
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("behaviourscience");
        echo "\">Behavioural Science</a></li>
                    <li><a href=\"";
        // line 51
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("computerscience");
        echo "\">Computer Science</a></li>
                    <li><a href=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("systemarchitect");
        echo "\">System Architecture</a></li>
                    <li><a href=\"";
        // line 53
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("allresources");
        echo "\">All Resources</a></li>
                </ul><!-- /End Menu Links -->
            </div><!-- /End Navbar Collapse -->
        </div><!-- /End Container -->
    </nav><!-- /End Navbar -->
</header>
";
        // line 59
        $this->displayBlock('body', $context, $blocks);
        // line 60
        echo "<section class=\"block contact text-center\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"contact-block\">
                <div class=\"icon\">
                    <img src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/contacticon.svg"), "html", null, true);
        echo " \" alt=\"contact-icon\">
                </div>
                <h2>Contact Us</h2>
                <p>We use range of social and media networks to keep our stakeholfers, investigators and those interested in the project up-to-date with developments. You can contact us through any of these networks and also sign up to our mailing list.</p>
                <a href=\"\" class=\"btn\">Contact</a>
            </div>
        </div>
    </div>
</section>
<footer class=\"footer\">
    <ul class=\"text-center footer-links list-inline\">
        <li><a href=\"#\">Grant Holders & Project Team</a></li>
        <li><a href=\"#\">Latest News</a></li>
        <li><a href=\"#\">Contact</a></li>
    </ul>
    <div class=\"container-fluid bottom-footer\">
        <div class=\"row\">
            <div class=\"col-sm-4 col-xs-5\">2017. Privacy Policy</div>
            <div class=\"col-sm-4 col-xs-2 text-center\"><a href=\"\"><img src=\"images/footer-twitter.svg\" alt=\"footer-twitter\"></a></div>
            <div class=\"col-sm-4 col-xs-5 text-right\">Site by British Websites</div>
        </div>
    </div>
</footer>
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
<!-- Latest compiled JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/js/bootstrap-select.js"), "html", null, true);
        echo "\"></script>
<script type=\"text/javascript\">
    \$(document).ready(function(){
        \$('#dp').click(function(){
            \$('.sh').slideToggle();
            \$('.dropdown').toggleClass('rotate');
        })
    })
        \$('.selectpicker').selectpicker({
  style: 'btn-info',
  size: 4
});
</script>
</body>

</html>
";
        
        $__internal_2885ecd57d0e6c96de9183b29aef914618780035e2ecc092dc806ce4bb134f35->leave($__internal_2885ecd57d0e6c96de9183b29aef914618780035e2ecc092dc806ce4bb134f35_prof);

    }

    // line 59
    public function block_body($context, array $blocks = array())
    {
        $__internal_9ffe41e8d18f10cbb54cbed129dea6b57466172e7535cf5ea5309bff73b7a0e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ffe41e8d18f10cbb54cbed129dea6b57466172e7535cf5ea5309bff73b7a0e3->enter($__internal_9ffe41e8d18f10cbb54cbed129dea6b57466172e7535cf5ea5309bff73b7a0e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_9ffe41e8d18f10cbb54cbed129dea6b57466172e7535cf5ea5309bff73b7a0e3->leave($__internal_9ffe41e8d18f10cbb54cbed129dea6b57466172e7535cf5ea5309bff73b7a0e3_prof);

    }

    public function getTemplateName()
    {
        return "home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 59,  157 => 91,  128 => 65,  121 => 60,  119 => 59,  110 => 53,  106 => 52,  102 => 51,  98 => 50,  89 => 44,  85 => 43,  76 => 37,  56 => 20,  52 => 19,  48 => 18,  44 => 17,  40 => 16,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!doctype html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

    <!-- TITLE OF SITE -->
    <title>Homepage</title>
\t<meta name=\"description\" content=\"\" />
    <meta name=\"keywords\" content=\"\" />
    <meta name=\"author\" content=\"\">
    <link href=\"https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900\" rel=\"stylesheet\">
    <link href=\"https://fonts.googleapis.com/css?family=Roboto+Condensed:400,700\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"{{ asset('vendors/frontend/css/bootstrap.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('vendors/frontend/css/bootstrap-select.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('vendors/frontend/css/custom.css') }} \">
    <link rel=\"stylesheet\" href=\"{{ asset('vendors/frontend/css/bootstrap-select.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('vendors/frontend/css/responsive.css') }}\">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
</head>
<body>
<header class=\"header\">       
    <nav class=\"index-header navbar \" id=\"main-navbar\">
        <div class=\"container\">
            <!-- Menu Button for Mobile Devices -->
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#navbar-collapse\">
                    <ul class=\"list-inline\">
                        <li><img src=\"{{ asset('vendors/frontend/images/mob-menu.svg') }}\" class=\"\" alt=\"mob-menu\">
                          
                        </li>
                        <li><span class=\"\">Menu</span></li>
                    </ul>
                </button>
                <a href=\"{{ url('homepage') }}\" class=\"navbar-brand smooth-scroll\">
                \t<img src=\"{{ asset('vendors/frontend/images/logo.svg') }}\" class=\"logo_height\" alt=\"logo\"/>
                </a>
            </div><!-- /End Navbar Header -->
            <div class=\"collapse navbar-collapse\" id=\"navbar-collapse\">
                <!-- Menu Links -->
                   <ul class=\"nav navbar-nav navbar-right\">
                    <li class=\"active\"><a href=\"{{ path('behaviourscience') }}\">Behavioural Science</a></li>
                    <li><a href=\"{{ path('computerscience') }}\">Computer Science</a></li>
                    <li><a href=\"{{ path('systemarchitect') }}\">System Architecture</a></li>
                    <li><a href=\"{{ path('allresources') }}\">All Resources</a></li>
                </ul><!-- /End Menu Links -->
            </div><!-- /End Navbar Collapse -->
        </div><!-- /End Container -->
    </nav><!-- /End Navbar -->
</header>
{% block body %}{% endblock %}
<section class=\"block contact text-center\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"contact-block\">
                <div class=\"icon\">
                    <img src=\"{{ asset('vendors/frontend/images/contacticon.svg') }} \" alt=\"contact-icon\">
                </div>
                <h2>Contact Us</h2>
                <p>We use range of social and media networks to keep our stakeholfers, investigators and those interested in the project up-to-date with developments. You can contact us through any of these networks and also sign up to our mailing list.</p>
                <a href=\"\" class=\"btn\">Contact</a>
            </div>
        </div>
    </div>
</section>
<footer class=\"footer\">
    <ul class=\"text-center footer-links list-inline\">
        <li><a href=\"#\">Grant Holders & Project Team</a></li>
        <li><a href=\"#\">Latest News</a></li>
        <li><a href=\"#\">Contact</a></li>
    </ul>
    <div class=\"container-fluid bottom-footer\">
        <div class=\"row\">
            <div class=\"col-sm-4 col-xs-5\">2017. Privacy Policy</div>
            <div class=\"col-sm-4 col-xs-2 text-center\"><a href=\"\"><img src=\"images/footer-twitter.svg\" alt=\"footer-twitter\"></a></div>
            <div class=\"col-sm-4 col-xs-5 text-right\">Site by British Websites</div>
        </div>
    </div>
</footer>
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
<!-- Latest compiled JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
<script src=\"{{ asset('vendors/frontend/js/bootstrap-select.js') }}\"></script>
<script type=\"text/javascript\">
    \$(document).ready(function(){
        \$('#dp').click(function(){
            \$('.sh').slideToggle();
            \$('.dropdown').toggleClass('rotate');
        })
    })
        \$('.selectpicker').selectpicker({
  style: 'btn-info',
  size: 4
});
</script>
</body>

</html>
", "home.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/home.html.twig");
    }
}
