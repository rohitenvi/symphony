<?php

/* @FOSUser/Security/login_content.html.twig */
class __TwigTemplate_7e3f461fb810f74950b949291f0e5896f1377c85a4045c7db7b62100e5b32030 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca7aec9762791db02cf28f02eb6ba168ffda1bdb83fe35a8b2492626fc63d505 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca7aec9762791db02cf28f02eb6ba168ffda1bdb83fe35a8b2492626fc63d505->enter($__internal_ca7aec9762791db02cf28f02eb6ba168ffda1bdb83fe35a8b2492626fc63d505_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login_content.html.twig"));

        // line 1
        echo "<div class=\"wrapper pa-0\">
<!-- Main Content -->
<div class=\"page-wrapper pa-0 ma-0\">
<div class=\"container-fluid\">
<!-- Row -->
<div class=\"table-struct full-width full-height\">
<div class=\"table-cell vertical-align-middle\">
<div class=\"auth-form  ml-auto mr-auto no-float\">
";
        // line 9
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 10
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
";
        }
        // line 12
        echo "<div class=\"panel panel-default card-view mb-0\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Sign In</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-sm-12 col-xs-12\">
    <div class=\"form-wrap\">
<form  action=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
    ";
        // line 25
        if ((isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token"))) {
            // line 26
            echo "        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
            echo "\" />
    ";
        }
        // line 28
        echo "        <div class=\"form-group\">
        <label class=\"control-label mb-10\" for=\"exampleInputEmail_2\">Email address</label>
        <div class=\"input-group\">
        <input type=\"text\"  class=\"form-control\" id=\"exampleInputEmail_2\" name=\"_username\"  placeholder=\"Enter Username\" required=\"required\" />
        <div class=\"input-group-addon\"><i class=\"icon-envelope-open\"></i></div>
        </div>
        </div>
        
        <div class=\"form-group\">
        <label class=\"control-label mb-10\" for=\"exampleInputpwd_2\">Password</label>
        <div class=\"input-group\">
        <input type=\"password\"  class=\"form-control\"  id=\"exampleInputpwd_2\" name=\"_password\"  placeholder=\"Enter pwd\" required=\"required\" />
         <div class=\"input-group-addon\">
          <i class=\"icon-lock\"></i></div>
        </div></div>
                                                            
        <div class=\"form-group\">
        <div class=\"checkbox checkbox-success pr-10 pull-left\">
       <input id=\"remember_me\"  name=\"_remember_me\"  type=\"checkbox\" value=\"on\">
       <label for=\"remember_me\">remember me</label>
       </div>
       <a class=\"capitalize-font txt-danger block pt-5 pull-right\" href=\"";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "resetting/request  \">forgot password</a>
        <div class=\"clearfix\"></div>
        </div>
        
        <div class=\"form-group\">
        <button type=\"submit\"  name=\"_submit\" class=\"btn btn-success btn-block\">sign in</button>
        </div>
      
                                                        
        </form>
        </div></div></div></div></div></div>
        </div></div>
        </div>
        <!-- /Row -->   
        </div>
        </div>
            <!-- /Main Content -->
        </div>";
        
        $__internal_ca7aec9762791db02cf28f02eb6ba168ffda1bdb83fe35a8b2492626fc63d505->leave($__internal_ca7aec9762791db02cf28f02eb6ba168ffda1bdb83fe35a8b2492626fc63d505_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 49,  66 => 28,  60 => 26,  58 => 25,  54 => 24,  40 => 12,  34 => 10,  32 => 9,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"wrapper pa-0\">
<!-- Main Content -->
<div class=\"page-wrapper pa-0 ma-0\">
<div class=\"container-fluid\">
<!-- Row -->
<div class=\"table-struct full-width full-height\">
<div class=\"table-cell vertical-align-middle\">
<div class=\"auth-form  ml-auto mr-auto no-float\">
{% if error %}
    <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
{% endif %}
<div class=\"panel panel-default card-view mb-0\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Sign In</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-sm-12 col-xs-12\">
    <div class=\"form-wrap\">
<form  action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
    {% if csrf_token %}
        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />
    {% endif %}
        <div class=\"form-group\">
        <label class=\"control-label mb-10\" for=\"exampleInputEmail_2\">Email address</label>
        <div class=\"input-group\">
        <input type=\"text\"  class=\"form-control\" id=\"exampleInputEmail_2\" name=\"_username\"  placeholder=\"Enter Username\" required=\"required\" />
        <div class=\"input-group-addon\"><i class=\"icon-envelope-open\"></i></div>
        </div>
        </div>
        
        <div class=\"form-group\">
        <label class=\"control-label mb-10\" for=\"exampleInputpwd_2\">Password</label>
        <div class=\"input-group\">
        <input type=\"password\"  class=\"form-control\"  id=\"exampleInputpwd_2\" name=\"_password\"  placeholder=\"Enter pwd\" required=\"required\" />
         <div class=\"input-group-addon\">
          <i class=\"icon-lock\"></i></div>
        </div></div>
                                                            
        <div class=\"form-group\">
        <div class=\"checkbox checkbox-success pr-10 pull-left\">
       <input id=\"remember_me\"  name=\"_remember_me\"  type=\"checkbox\" value=\"on\">
       <label for=\"remember_me\">remember me</label>
       </div>
       <a class=\"capitalize-font txt-danger block pt-5 pull-right\" href=\"{{ url('homepage') }}resetting/request  \">forgot password</a>
        <div class=\"clearfix\"></div>
        </div>
        
        <div class=\"form-group\">
        <button type=\"submit\"  name=\"_submit\" class=\"btn btn-success btn-block\">sign in</button>
        </div>
      
                                                        
        </form>
        </div></div></div></div></div></div>
        </div></div>
        </div>
        <!-- /Row -->   
        </div>
        </div>
            <!-- /Main Content -->
        </div>", "@FOSUser/Security/login_content.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/FOSUserBundle/views/Security/login_content.html.twig");
    }
}
