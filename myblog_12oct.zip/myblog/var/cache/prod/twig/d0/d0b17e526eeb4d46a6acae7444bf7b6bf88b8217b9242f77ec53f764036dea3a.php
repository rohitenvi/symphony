<?php

/* @FOSUser/layout.html.twig */
class __TwigTemplate_4391b79bdbc16f5ffb43608d4f6ce4698bf3f9224787a8bb83b6a9eaa8ba22c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9682ffd983665ea16e941ea21a6bb36526848c7a9942696246b3feab90478302 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9682ffd983665ea16e941ea21a6bb36526848c7a9942696246b3feab90478302->enter($__internal_9682ffd983665ea16e941ea21a6bb36526848c7a9942696246b3feab90478302_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />
      <link href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/jasny-bootstrap/dist/css/jasny-bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/> 

      <!-- Custom CSS -->
        <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">   
    </head>
    <body>
        <div>
            ";
        // line 13
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 14
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array())), "FOSUserBundle"), "html", null, true);
            echo " |
                <a href=\"";
            // line 15
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                    ";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
                </a>
            ";
        } else {
            // line 19
            echo "                <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
            ";
        }
        // line 21
        echo "        </div>

      

        <div>
            ";
        // line 26
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 28
        echo "        </div>

        <!-- jQuery -->
        <script src=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/jquery/dist/jquery.min.js"), "html", null, true);
        echo "\"></script>
        
        <!-- Bootstrap Core JavaScript -->
        <script src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/jasny-bootstrap/dist/js/jasny-bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        
        <!-- Slimscroll JavaScript -->
        <script src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/jquery.slimscroll.js"), "html", null, true);
        echo "\"></script>
    
        <!-- Fancy Dropdown JS -->
        <script src=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/dropdown-bootstrap-extended.js"), "html", null, true);
        echo "\"></script>
        
        <!-- Init JavaScript -->
        <script src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/init.js"), "html", null, true);
        echo "\"></script>


    </body>
</html>
";
        
        $__internal_9682ffd983665ea16e941ea21a6bb36526848c7a9942696246b3feab90478302->leave($__internal_9682ffd983665ea16e941ea21a6bb36526848c7a9942696246b3feab90478302_prof);

    }

    // line 26
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cab27f68a9290d8ea16b69ad73482c624950509b1faafb9cc86c6a972f08ee7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cab27f68a9290d8ea16b69ad73482c624950509b1faafb9cc86c6a972f08ee7f->enter($__internal_cab27f68a9290d8ea16b69ad73482c624950509b1faafb9cc86c6a972f08ee7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 27
        echo "            ";
        
        $__internal_cab27f68a9290d8ea16b69ad73482c624950509b1faafb9cc86c6a972f08ee7f->leave($__internal_cab27f68a9290d8ea16b69ad73482c624950509b1faafb9cc86c6a972f08ee7f_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 27,  123 => 26,  110 => 44,  104 => 41,  98 => 38,  92 => 35,  88 => 34,  82 => 31,  77 => 28,  75 => 26,  68 => 21,  60 => 19,  54 => 16,  50 => 15,  45 => 14,  43 => 13,  36 => 9,  30 => 6,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />
      <link href=\"{{ asset('vendors/bower_components/jasny-bootstrap/dist/css/jasny-bootstrap.min.css') }}\" rel=\"stylesheet\" type=\"text/css\"/> 

      <!-- Custom CSS -->
        <link href=\"{{ asset('dist/css/style.css') }}\" rel=\"stylesheet\" type=\"text/css\">   
    </head>
    <body>
        <div>
            {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
                {{ 'layout.logged_in_as'|trans({'%username%': app.user.username}, 'FOSUserBundle') }} |
                <a href=\"{{ path('fos_user_security_logout') }}\">
                    {{ 'layout.logout'|trans({}, 'FOSUserBundle') }}
                </a>
            {% else %}
                <a href=\"{{ path('fos_user_security_login') }}\">{{ 'layout.login'|trans({}, 'FOSUserBundle') }}</a>
            {% endif %}
        </div>

      

        <div>
            {% block fos_user_content %}
            {% endblock fos_user_content %}
        </div>

        <!-- jQuery -->
        <script src=\"{{ asset('vendors/bower_components/jquery/dist/jquery.min.js') }}\"></script>
        
        <!-- Bootstrap Core JavaScript -->
        <script src=\"{{ asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js') }}\"></script>
        <script src=\"{{ asset('vendors/bower_components/jasny-bootstrap/dist/js/jasny-bootstrap.min.js') }}\"></script>
        
        <!-- Slimscroll JavaScript -->
        <script src=\"{{ asset('dist/js/jquery.slimscroll.js') }}\"></script>
    
        <!-- Fancy Dropdown JS -->
        <script src=\"{{ asset('dist/js/dropdown-bootstrap-extended.js') }}\"></script>
        
        <!-- Init JavaScript -->
        <script src=\"{{ asset('dist/js/init.js') }}\"></script>


    </body>
</html>
", "@FOSUser/layout.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/FOSUserBundle/views/layout.html.twig");
    }
}
