<?php

/* /admin/dashboard/dashboard.html.twig */
class __TwigTemplate_ad6cbe160725400b38aaefa6ac91d22adaa0e7bad65ef5d38fc43a74420f3095 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("adminlayout.html.twig", "/admin/dashboard/dashboard.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "adminlayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e44cb0748efa6d2af604ccc966dd5b79839a4a0c4d1b957a2b870cf931efa9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e44cb0748efa6d2af604ccc966dd5b79839a4a0c4d1b957a2b870cf931efa9c->enter($__internal_4e44cb0748efa6d2af604ccc966dd5b79839a4a0c4d1b957a2b870cf931efa9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/admin/dashboard/dashboard.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4e44cb0748efa6d2af604ccc966dd5b79839a4a0c4d1b957a2b870cf931efa9c->leave($__internal_4e44cb0748efa6d2af604ccc966dd5b79839a4a0c4d1b957a2b870cf931efa9c_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_629f94ec25f7394f75a5572f9bb914dcef975288b8f825238cc7a602b2a33f05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_629f94ec25f7394f75a5572f9bb914dcef975288b8f825238cc7a602b2a33f05->enter($__internal_629f94ec25f7394f75a5572f9bb914dcef975288b8f825238cc7a602b2a33f05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo " <div class=\"page-wrapper\">
            <div class=\"container-fluid\">
                
            
                <div class=\"row heading-bg  bg-red\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12\">
                        <h5 class=\"txt-light\">Welcome To Admin Panel</h5>
                    </div>
                
                    <div class=\"col-lg-9 col-sm-8 col-md-8 col-xs-12\">
                        <ol class=\"breadcrumb\">
                            <li><a href=\"#\">Dashboard</a></li>
                            
                        </ol>
                    </div>
                
                </div>
                
                
            </div>
            </div>
            ";
        
        $__internal_629f94ec25f7394f75a5572f9bb914dcef975288b8f825238cc7a602b2a33f05->leave($__internal_629f94ec25f7394f75a5572f9bb914dcef975288b8f825238cc7a602b2a33f05_prof);

    }

    public function getTemplateName()
    {
        return "/admin/dashboard/dashboard.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'adminlayout.html.twig' %}
{% block body %}
 <div class=\"page-wrapper\">
            <div class=\"container-fluid\">
                
            
                <div class=\"row heading-bg  bg-red\">
                    <div class=\"col-lg-3 col-md-4 col-sm-4 col-xs-12\">
                        <h5 class=\"txt-light\">Welcome To Admin Panel</h5>
                    </div>
                
                    <div class=\"col-lg-9 col-sm-8 col-md-8 col-xs-12\">
                        <ol class=\"breadcrumb\">
                            <li><a href=\"#\">Dashboard</a></li>
                            
                        </ol>
                    </div>
                
                </div>
                
                
            </div>
            </div>
            {% endblock %}", "/admin/dashboard/dashboard.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/admin/dashboard/dashboard.html.twig");
    }
}
