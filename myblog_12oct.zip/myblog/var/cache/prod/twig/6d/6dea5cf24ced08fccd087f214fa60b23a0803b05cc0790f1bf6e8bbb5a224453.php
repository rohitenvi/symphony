<?php

/* adminlayout.html.twig */
class __TwigTemplate_d97e48bb0e49c1d4528493d31b2c734bc1774c1e81adf31e152c7e19f0d94069 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef346b1d67370e85cb9a017781be105d9b9b00bb3e40a3545b3736790ca6d7c2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef346b1d67370e85cb9a017781be105d9b9b00bb3e40a3545b3736790ca6d7c2->enter($__internal_ef346b1d67370e85cb9a017781be105d9b9b00bb3e40a3545b3736790ca6d7c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "adminlayout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
 <meta charset=\"UTF-8\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />
<title>HBCP</title>
<meta name=\"description\" content=\"Kenny is a Dashboard & Admin Site Responsive Template by hencework.\" />
<meta name=\"keywords\" content=\"admin, admin dashboard, admin template, cms, crm, Kenny Admin, kennyadmin, premium admin templates, responsive admin, sass, panel, software, ui, visualization, web app, application\" />
<meta name=\"author\" content=\"hencework\"/>
\t

<link rel=\"shortcut icon\" href=\"favicon.ico\">
<link rel=\"icon\" href=\"favicon.ico\" type=\"image/x-icon\">
\t

<link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/morris.js/morris.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
\t
\t
\t<link href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/datatables/media/css/jquery.dataTables.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>
\t
\t<link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">
\t<link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/dropzone/dist/dropzone.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\"/>

\t<link href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">

 
    </script>
</head>

<body>

\t<div class=\"preloader-it\">
        <div class=\"la-anim-1\"></div>
    </div>
    <div class=\"wrapper\">
        
        <nav class=\"navbar navbar-inverse navbar-fixed-top\">
                <a id=\"toggle_nav_btn\" class=\"toggle-left-nav-btn inline-block mr-20 pull-left\" href=\"javascript:void(0);\"><i class=\"fa fa-bars\"></i></a>
                <a href=\"";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/dashboard\"><img class=\"brand-img pull-left\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/logo.svg"), "html", null, true);
        echo "\" height='30px' alt=\"brand\"/></a>
                <ul class=\"nav navbar-right top-nav pull-right\">
                    
                    <li class=\"dropdown\">
                        <a href=\"javascript:void(0)\" class=\"dropdown-toggle pr-0\" data-toggle=\"dropdown\"><img src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user1.png"), "html", null, true);
        echo "\" alt=\"user_auth\" class=\"user-auth-img img-circle\"/><span class=\"user-online-status\"></span></a>
                        <ul class=\"dropdown-menu user-auth-dropdown\" data-dropdown-in=\"fadeIn\" data-dropdown-out=\"fadeOut\">
                            <li>
                                <a href=\"javascript:void(0)\"><i class=\"fa fa-fw fa-user\"></i> Profile</a>
                            </li>
                            
                            
                            <li class=\"divider\"></li>
                            <li>
                                <a href=\"";
        // line 52
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "logout\"><i class=\"fa fa-fw fa-power-off\"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class=\"collapse navbar-search-overlap\" id=\"site_navbar_search\">
                    <form role=\"search\">
                        <div class=\"form-group mb-0\">
                            <div class=\"input-search\">
                                <div class=\"input-group\">   
                                    <input type=\"text\" id=\"overlay_search\" name=\"overlay-search\" class=\"form-control pl-30\" placeholder=\"Search\">
                                    <span class=\"input-group-addon pr-30\">
                                    <a  href=\"javascript:void(0)\" class=\"close-input-overlay\" data-target=\"#site_navbar_search\" data-toggle=\"collapse\" aria-label=\"Close\" aria-expanded=\"true\"><i class=\"fa fa-times\"></i></a>
                                    </span> 
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </nav> ";
        // line 72
        echo "      <div class=\"fixed-sidebar-left\">
                <ul class=\"nav navbar-nav side-nav nicescroll-bar\">
                    <li>
                        <a  class=\"active\" href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#dashboard_dr\"><i class=\"icon-picture mr-10\"></i>News Dashboard <span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"dashboard_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a class=\"active\" href=\"";
        // line 78
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/allnews\">NEWS</a>
                            </li>
                            <li>
                                <a class=\"active\" href=\"";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/createnew\"> Create New</a>
                            </li>
                        </ul>
                    </li>
                            <li>
                        <a href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#app_dr\"><i class=\"icon-grid mr-10\"></i>Category<span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"app_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a href=\"";
        // line 89
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/cats/all\">All Category</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 92
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/cat/create\">Create A Category</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#kpp_dr\"><i class=\"icon-grid mr-10\"></i>Resource Type Section <span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"kpp_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a href=\"";
        // line 100
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/resourcetype/all\">All Resource Type</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 103
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/resourcetype/create\">Create A Resource Type</a>
                            </li>
                        </ul>
                    </li>

                        <li>
                        <a href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#kppp_dr\"><i class=\"icon-grid mr-10\"></i>Resource  Section <span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"kppp_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a href=\"";
        // line 112
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/allresources\">All Resources</a>
                            </li>
                            <li>
                                <a href=\"";
        // line 115
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/resource/createnew\">Create A Resource </a>
                            </li>
                        </ul>
                    </li>



                   </ul>
            </div>
            <div class=\"fixed-sidebar-right\">
                <ul class=\"right-sidebar nicescroll-bar\">
                    <li>
                        <div  class=\"tab-struct custom-tab-1\">
                            <ul role=\"tablist\" class=\"nav nav-tabs\" id=\"right_sidebar_tab\">
                                <li class=\"active\" role=\"presentation\"><a aria-expanded=\"true\"  data-toggle=\"tab\" role=\"tab\" id=\"chat_tab_btn\" href=\"#chat_tab\">chat</a></li>
                                <li role=\"presentation\" class=\"\"><a  data-toggle=\"tab\" id=\"messages_tab_btn\" role=\"tab\" href=\"#messages_tab\" aria-expanded=\"false\">messages</a></li>
                                <li role=\"presentation\" class=\"\"><a  data-toggle=\"tab\" id=\"todo_tab_btn\" role=\"tab\" href=\"#todo_tab\" aria-expanded=\"false\">todo</a></li>
                            </ul>
    <div class=\"tab-content\" id=\"right_sidebar_content\">
                                <div  id=\"chat_tab\" class=\"tab-pane fade active in\" role=\"tabpanel\">
                                    <div class=\"chat-cmplt-wrap\">
                                        <div class=\"chat-box-wrap\">
                                            <form role=\"search\">
                                                <div class=\"input-group mb-15\">
                                                    <input type=\"text\" id=\"example-input1-group2\" name=\"example-input1-group2\" class=\"form-control\" placeholder=\"Search\">
                                                    <span class=\"input-group-btn\">
                                                    <button type=\"button\" class=\"btn  btn-default\"><i class=\"fa fa-search\"></i></button>
                                                    </span>
                                                </div>
                                            </form>
        <ul class=\"chat-list-wrap\">
        <li class=\"chat-list\">
        <div class=\"chat-body\">
        <a  href=\"javascript:void(0)\">
        <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user.png"), "html", null, true);
        echo "\" alt=\"user\"/>
    <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status away\"></div>
    <div class=\"clearfix\"></div>
    </div>
    </a>
    <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"";
        // line 161
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user1.png"), "html", null, true);
        echo " \" alt=\"user\"/>
    <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">1pm</span>
    </div>
    <div class=\"status offline\"></div>
    <div class=\"clearfix\"></div>
    </div>
    </a>
    <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"";
        // line 172
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user2.png"), "html", null, true);
        echo "\" alt=\"user\"/>
   <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status online\"></div>
    <div class=\"clearfix\"></div>
    </div></a>
     <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"";
        // line 182
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user3.png"), "html", null, true);
        echo "\" alt=\"user\"/>
   <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status online\"></div>
    <div class=\"clearfix\"></div>
    </div>
     </a>
    <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user4.png"), "html", null, true);
        echo "\" alt=\"user\"/>
    <div class=\"user-data\">
   <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status online\"></div>
    <div class=\"clearfix\"></div>
    </div></a>
    </div>
    </li>
    </ul>
    </div>
    <div class=\"recent-chat-box-wrap\">
    <div class=\"panel panel-success card-view\">
    <div class=\"panel-heading mb-20\">
    <a class=\"goto-chat-list txt-light\" href=\"javascript:void(0);\"><i class=\"ti-angle-left\"></i></a>
    <div class=\"text-center\">
    <h6 class=\"panel-title txt-light\">Alan Gilchrist</h6></div>
    <div class=\"clearfix\"></div>
    </div>
    <div class=\"panel-wrapper collapse in\">
    <div class=\"panel-body\">
    <div class=\"chat-content\">
    <ul>
    <li class=\"friend\">
    <div class=\"friend-msg-wrap\"></div> 
    </li>
    <li class=\"self\">
    <div class=\"self-msg-wrap\">
    </div>  
    </li>
    <li class=\"friend\">
    <div class=\"friend-msg-wrap\"></div> 
    </li>
    </ul>
    </div>
    <div class=\"input-group\">
    <div class=\"input-group-btn\">
    <div class=\"dropup\">
    <button type=\"button\" class=\"btn  btn-default  dropdown-toggle\" data-toggle=\"dropdown\" ><i class=\"fa fa-smile-o\"></i></button>
    <ul class=\"dropdown-menu dropdown-menu-right\">
    </ul>
</div></div>
<input type=\"text\" id=\"input_msg_send\" name=\"send-msg\" class=\"form-control\" placeholder=\"Type something\">
<div class=\"input-group-btn\">
<div class=\"fileupload btn  btn-default\"><i class=\"fa fa-paperclip\">
</i>
<input type=\"file\" class=\"upload\">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id=\"messages_tab\" class=\"tab-pane fade\" role=\"tabpanel\">
<div class=\"message-box-wrap\">
<div class=\"streamline message-box\">
<div class=\"sl-item\">
<div class=\"sl-avatar avatar avatar-sm avatar-circle\">
<img class=\"img-responsive img-circle\" src=\"";
        // line 255
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user.png"), "html", null, true);
        echo "\" alt=\"avatar\"/>
</div>
<div class=\"sl-content\">
<a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
<span class=\"inline-block font-12 mb-5 pull-right\">12/10/16</span>
<div class=\"clearfix\"></div>
<p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
</div></div><hr/>
<div class=\"sl-item\">
<div class=\"sl-avatar avatar avatar-sm avatar-circle\">
<img class=\"img-responsive img-circle\" src=\"";
        // line 265
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user1.png"), "html", null, true);
        echo "\" alt=\"avatar\"/>
</div>
<div class=\"sl-content\">
<a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
<span class=\"inline-block font-12 mb-5 pull-right\">2pm</span>
<div class=\"clearfix\"></div>
<p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
</div>
</div>
<hr/>
<div class=\"sl-item\">
                                                <div class=\"sl-avatar avatar avatar-sm avatar-circle\">
                                                    <img class=\"img-responsive img-circle\" src=\"";
        // line 277
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user2.png"), "html", null, true);
        echo "\" alt=\"avatar\"/>
                                                </div>
                                                <div class=\"sl-content\">
                                                    <a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
                                                    <span class=\"inline-block font-12 mb-5 pull-right\">1pm</span>
                                                    <div class=\"clearfix\"></div>
                                                    <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
                                                </div>
                                            </div>
                                            <hr/>
                                            <div class=\"sl-item\">
                                                <div class=\"sl-avatar avatar avatar-sm avatar-circle\">
                                                    <img class=\"img-responsive img-circle\" src=\"";
        // line 289
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user3.png"), "html", null, true);
        echo "\" alt=\"avatar\"/>
                                                </div>
                                                <div class=\"sl-content\">
                                                    <a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
                                                    <span class=\"inline-block font-12 mb-5 pull-right\">1pm</span>
                                                    <div class=\"clearfix\"></div>
                                                    <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
                                                </div>
                                            </div>
                                            <hr/>
                                            <div class=\"sl-item\">
                                                <div class=\"sl-avatar avatar avatar-sm avatar-circle\">
                                                    <img class=\"img-responsive img-circle\" src=\"";
        // line 301
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/img/user4.png"), "html", null, true);
        echo "\" alt=\"avatar\"/>
                                                </div>
                                                <div class=\"sl-content\">
                                                    <a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
                                                    <span class=\"inline-block font-12 mb-5 pull-right\">1pm</span>
                                                    <div class=\"clearfix\"></div>
                                                    <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div  id=\"todo_tab\" class=\"tab-pane fade\" role=\"tabpanel\">
                                    <div class=\"todo-box-wrap\">
                                        
                                        <ul class=\"todo-list\">
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-default\">
                                                    <input type=\"checkbox\" id=\"checkbox01\"/>
                                                    <label for=\"checkbox01\">Record The First Episode Of HTML Tutorial</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-pink\">
                                                    <input type=\"checkbox\" id=\"checkbox02\"/>
                                                    <label for=\"checkbox02\">Prepare The Conference Schedule</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-warning\">
                                                    <input type=\"checkbox\" id=\"checkbox03\" checked/>
                                                    <label for=\"checkbox03\">Decide The Live Discussion Time</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-success\">
                                                    <input type=\"checkbox\" id=\"checkbox04\" checked/>
                                                    <label for=\"checkbox04\">Prepare For The Next Project</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-danger\">
                                                    <input type=\"checkbox\" id=\"checkbox05\" checked/>
                                                    <label for=\"checkbox05\">Finish Up AngularJs Tutorial</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-purple\">
                                                    <input type=\"checkbox\" id=\"checkbox06\" checked/>
                                                    <label for=\"checkbox06\">Finish Infinity Project</label>
                                                </div>
                                            </li>
                                        </ul>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
 ";
        // line 362
        $this->displayBlock('body', $context, $blocks);
        // line 363
        echo "        
          
            
            
        </div>
       

    </div>



    </div>";
        // line 375
        echo "
    
    <script src=\"";
        // line 377
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/jquery/dist/jquery.min.js"), "html", null, true);
        echo "\"></script>


    <script src=\"";
        // line 380
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    
\t<script src=\"";
        // line 382
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/dataTables-data.js"), "html", null, true);
        echo "\"></script>
    
\t<script src=\"";
        // line 384
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/datatables/media/js/jquery.dataTables.min.js"), "html", null, true);
        echo "\"></script>
\t
 
\t<script src=\"";
        // line 387
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/jquery.slimscroll.js"), "html", null, true);
        echo "\"></script>
\t
\t
\t<script src=\"";
        // line 390
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/moment/min/moment.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 391
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/simpleWeather/jquery.simpleWeather.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 392
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/simpleweather-data.js"), "html", null, true);
        echo "\"></script>
\t
\t
\t<script src=\"";
        // line 395
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/waypoints/lib/jquery.waypoints.min.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 396
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/Counter-Up/jquery.counterup.min.js"), "html", null, true);
        echo "\"></script>
\t

\t<script src=\"";
        // line 399
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/dropdown-bootstrap-extended.js"), "html", null, true);
        echo "\"></script>
\t

        <script src=\"";
        // line 402
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/dropzone/dist/dropzone.js"), "html", null, true);
        echo "\"></script>


\t<script src=\"";
        // line 405
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/jquery.sparkline/dist/jquery.sparkline.min.js"), "html", null, true);
        echo "\"></script>
\t

\t<script src=\"";
        // line 408
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/chart.js/Chart.min.js"), "html", null, true);
        echo "\"></script>
\t

    <script src=\"";
        // line 411
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/raphael/raphael.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 412
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/morris.js/morris.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 413
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/morris-data.js"), "html", null, true);
        echo "\"></script>
\t
\t<script src=\"";
        // line 415
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js"), "html", null, true);
        echo "\"></script>
\t

\t<script src=\"";
        // line 418
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/init.js"), "html", null, true);
        echo "\"></script>
\t<script src=\"";
        // line 419
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("dist/js/dashboard_data.js"), "html", null, true);
        echo "\"></script>
    <script>
\$('body').on('click','.confirmation' , function () {
        return confirm('Are you sure?');
    });

\$('#typeofpath').on('change',function(){
var rok = \$(this).val();
if( rok == 'dropbox' )
{
\$('.catype').css('display','block');
    
}
else{
\$('.catype').css('display','none');
}
});



\$(document).ready(function() {
\$(\"#topcat\").change(function () {
var option = \$('option:selected', this).val();
      \$(\"#unlockcat\")
          .find(\"option\")
          .show()
          .not(\"option[toparent~='\" + option + \"']\").hide();
     
   \$(\"#unlockcat\").val(
      \$(\"#unlockcat\").find(\"option:visible:first\").val()); 
  }).change();


\$(\"#topcatedit\").on('change', function () {

var option = \$('option:selected', this).val();
\$(\"#unlockcatedit\")
          .find(\"option\")
          .show()
          .not(\"option[toparent~='\" + option + \"']\").hide();

    \$(\"#unlockcatedit\").val(
      \$(\"#unlockcatedit\").find(\"option:visible:first\").val());       
});
});

\$('#typeofpath').on('change',function(){
var resourcetype = \$(this).val();
if(resourcetype == 'dropbox'){

\$('#resourcetype').attr('required','required');
}else{

\$('#resourcetype').removeAttr('required');

}


});

    </script>
<style>
.footer{
position:relative!important;  
}
</style>
</body>

</html>";
        
        $__internal_ef346b1d67370e85cb9a017781be105d9b9b00bb3e40a3545b3736790ca6d7c2->leave($__internal_ef346b1d67370e85cb9a017781be105d9b9b00bb3e40a3545b3736790ca6d7c2_prof);

    }

    // line 362
    public function block_body($context, array $blocks = array())
    {
        $__internal_05bd239baa0498afacefe416e6e6002ee49a7860c02eefe87263acdaba6d7d92 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05bd239baa0498afacefe416e6e6002ee49a7860c02eefe87263acdaba6d7d92->enter($__internal_05bd239baa0498afacefe416e6e6002ee49a7860c02eefe87263acdaba6d7d92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_05bd239baa0498afacefe416e6e6002ee49a7860c02eefe87263acdaba6d7d92->leave($__internal_05bd239baa0498afacefe416e6e6002ee49a7860c02eefe87263acdaba6d7d92_prof);

    }

    public function getTemplateName()
    {
        return "adminlayout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  661 => 362,  585 => 419,  581 => 418,  575 => 415,  570 => 413,  566 => 412,  562 => 411,  556 => 408,  550 => 405,  544 => 402,  538 => 399,  532 => 396,  528 => 395,  522 => 392,  518 => 391,  514 => 390,  508 => 387,  502 => 384,  497 => 382,  492 => 380,  486 => 377,  482 => 375,  469 => 363,  467 => 362,  403 => 301,  388 => 289,  373 => 277,  358 => 265,  345 => 255,  280 => 193,  266 => 182,  253 => 172,  239 => 161,  225 => 150,  187 => 115,  181 => 112,  169 => 103,  163 => 100,  152 => 92,  146 => 89,  135 => 81,  129 => 78,  121 => 72,  99 => 52,  87 => 43,  78 => 39,  60 => 24,  55 => 22,  51 => 21,  46 => 19,  40 => 16,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
 <meta charset=\"UTF-8\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />
<title>HBCP</title>
<meta name=\"description\" content=\"Kenny is a Dashboard & Admin Site Responsive Template by hencework.\" />
<meta name=\"keywords\" content=\"admin, admin dashboard, admin template, cms, crm, Kenny Admin, kennyadmin, premium admin templates, responsive admin, sass, panel, software, ui, visualization, web app, application\" />
<meta name=\"author\" content=\"hencework\"/>
\t

<link rel=\"shortcut icon\" href=\"favicon.ico\">
<link rel=\"icon\" href=\"favicon.ico\" type=\"image/x-icon\">
\t

<link href=\"{{asset('vendors/bower_components/morris.js/morris.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
\t
\t
\t<link href=\"{{asset('vendors/bower_components/datatables/media/css/jquery.dataTables.min.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>
\t
\t<link href=\"{{asset('vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.css')}}\" rel=\"stylesheet\" type=\"text/css\">
\t<link href=\"{{asset('vendors/bower_components/dropzone/dist/dropzone.css')}}\" rel=\"stylesheet\" type=\"text/css\"/>

\t<link href=\"{{asset('dist/css/style.css')}}\" rel=\"stylesheet\" type=\"text/css\">

 
    </script>
</head>

<body>

\t<div class=\"preloader-it\">
        <div class=\"la-anim-1\"></div>
    </div>
    <div class=\"wrapper\">
        
        <nav class=\"navbar navbar-inverse navbar-fixed-top\">
                <a id=\"toggle_nav_btn\" class=\"toggle-left-nav-btn inline-block mr-20 pull-left\" href=\"javascript:void(0);\"><i class=\"fa fa-bars\"></i></a>
                <a href=\"{{ url('homepage') }}admin/dashboard\"><img class=\"brand-img pull-left\" src=\"{{asset('vendors/logo.svg') }}\" height='30px' alt=\"brand\"/></a>
                <ul class=\"nav navbar-right top-nav pull-right\">
                    
                    <li class=\"dropdown\">
                        <a href=\"javascript:void(0)\" class=\"dropdown-toggle pr-0\" data-toggle=\"dropdown\"><img src=\"{{asset('dist/img/user1.png') }}\" alt=\"user_auth\" class=\"user-auth-img img-circle\"/><span class=\"user-online-status\"></span></a>
                        <ul class=\"dropdown-menu user-auth-dropdown\" data-dropdown-in=\"fadeIn\" data-dropdown-out=\"fadeOut\">
                            <li>
                                <a href=\"javascript:void(0)\"><i class=\"fa fa-fw fa-user\"></i> Profile</a>
                            </li>
                            
                            
                            <li class=\"divider\"></li>
                            <li>
                                <a href=\"{{ url('homepage') }}logout\"><i class=\"fa fa-fw fa-power-off\"></i> Log Out</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class=\"collapse navbar-search-overlap\" id=\"site_navbar_search\">
                    <form role=\"search\">
                        <div class=\"form-group mb-0\">
                            <div class=\"input-search\">
                                <div class=\"input-group\">   
                                    <input type=\"text\" id=\"overlay_search\" name=\"overlay-search\" class=\"form-control pl-30\" placeholder=\"Search\">
                                    <span class=\"input-group-addon pr-30\">
                                    <a  href=\"javascript:void(0)\" class=\"close-input-overlay\" data-target=\"#site_navbar_search\" data-toggle=\"collapse\" aria-label=\"Close\" aria-expanded=\"true\"><i class=\"fa fa-times\"></i></a>
                                    </span> 
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </nav> {# end of navbar #}
      <div class=\"fixed-sidebar-left\">
                <ul class=\"nav navbar-nav side-nav nicescroll-bar\">
                    <li>
                        <a  class=\"active\" href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#dashboard_dr\"><i class=\"icon-picture mr-10\"></i>News Dashboard <span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"dashboard_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a class=\"active\" href=\"{{ url('homepage') }}admin/allnews\">NEWS</a>
                            </li>
                            <li>
                                <a class=\"active\" href=\"{{ url('homepage') }}admin/createnew\"> Create New</a>
                            </li>
                        </ul>
                    </li>
                            <li>
                        <a href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#app_dr\"><i class=\"icon-grid mr-10\"></i>Category<span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"app_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a href=\"{{ url('homepage') }}admin/cats/all\">All Category</a>
                            </li>
                            <li>
                                <a href=\"{{ url('homepage') }}admin/cat/create\">Create A Category</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#kpp_dr\"><i class=\"icon-grid mr-10\"></i>Resource Type Section <span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"kpp_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a href=\"{{ url('homepage') }}admin/resourcetype/all\">All Resource Type</a>
                            </li>
                            <li>
                                <a href=\"{{ url('homepage') }}admin/resourcetype/create\">Create A Resource Type</a>
                            </li>
                        </ul>
                    </li>

                        <li>
                        <a href=\"javascript:void(0);\" data-toggle=\"collapse\" data-target=\"#kppp_dr\"><i class=\"icon-grid mr-10\"></i>Resource  Section <span class=\"pull-right\"><i class=\"fa fa-fw fa-angle-down\"></i></span></a>
                        <ul id=\"kppp_dr\" class=\"collapse collapse-level-1\">
                            <li>
                                <a href=\"{{ url('homepage') }}admin/allresources\">All Resources</a>
                            </li>
                            <li>
                                <a href=\"{{ url('homepage') }}admin/resource/createnew\">Create A Resource </a>
                            </li>
                        </ul>
                    </li>



                   </ul>
            </div>
            <div class=\"fixed-sidebar-right\">
                <ul class=\"right-sidebar nicescroll-bar\">
                    <li>
                        <div  class=\"tab-struct custom-tab-1\">
                            <ul role=\"tablist\" class=\"nav nav-tabs\" id=\"right_sidebar_tab\">
                                <li class=\"active\" role=\"presentation\"><a aria-expanded=\"true\"  data-toggle=\"tab\" role=\"tab\" id=\"chat_tab_btn\" href=\"#chat_tab\">chat</a></li>
                                <li role=\"presentation\" class=\"\"><a  data-toggle=\"tab\" id=\"messages_tab_btn\" role=\"tab\" href=\"#messages_tab\" aria-expanded=\"false\">messages</a></li>
                                <li role=\"presentation\" class=\"\"><a  data-toggle=\"tab\" id=\"todo_tab_btn\" role=\"tab\" href=\"#todo_tab\" aria-expanded=\"false\">todo</a></li>
                            </ul>
    <div class=\"tab-content\" id=\"right_sidebar_content\">
                                <div  id=\"chat_tab\" class=\"tab-pane fade active in\" role=\"tabpanel\">
                                    <div class=\"chat-cmplt-wrap\">
                                        <div class=\"chat-box-wrap\">
                                            <form role=\"search\">
                                                <div class=\"input-group mb-15\">
                                                    <input type=\"text\" id=\"example-input1-group2\" name=\"example-input1-group2\" class=\"form-control\" placeholder=\"Search\">
                                                    <span class=\"input-group-btn\">
                                                    <button type=\"button\" class=\"btn  btn-default\"><i class=\"fa fa-search\"></i></button>
                                                    </span>
                                                </div>
                                            </form>
        <ul class=\"chat-list-wrap\">
        <li class=\"chat-list\">
        <div class=\"chat-body\">
        <a  href=\"javascript:void(0)\">
        <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"{{ asset('dist/img/user.png') }}\" alt=\"user\"/>
    <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status away\"></div>
    <div class=\"clearfix\"></div>
    </div>
    </a>
    <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"{{asset('dist/img/user1.png') }} \" alt=\"user\"/>
    <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">1pm</span>
    </div>
    <div class=\"status offline\"></div>
    <div class=\"clearfix\"></div>
    </div>
    </a>
    <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"{{asset('dist/img/user2.png') }}\" alt=\"user\"/>
   <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status online\"></div>
    <div class=\"clearfix\"></div>
    </div></a>
     <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"{{asset('dist/img/user3.png') }}\" alt=\"user\"/>
   <div class=\"user-data\">
    <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status online\"></div>
    <div class=\"clearfix\"></div>
    </div>
     </a>
    <a  href=\"javascript:void(0)\">
    <div class=\"chat-data\">
    <img class=\"user-img img-circle\"  src=\"{{asset('dist/img/user4.png') }}\" alt=\"user\"/>
    <div class=\"user-data\">
   <span class=\"name block capitalize-font\">ryan gosling</span>
    <span class=\"time block txt-grey\">2pm</span>
    </div>
    <div class=\"status online\"></div>
    <div class=\"clearfix\"></div>
    </div></a>
    </div>
    </li>
    </ul>
    </div>
    <div class=\"recent-chat-box-wrap\">
    <div class=\"panel panel-success card-view\">
    <div class=\"panel-heading mb-20\">
    <a class=\"goto-chat-list txt-light\" href=\"javascript:void(0);\"><i class=\"ti-angle-left\"></i></a>
    <div class=\"text-center\">
    <h6 class=\"panel-title txt-light\">Alan Gilchrist</h6></div>
    <div class=\"clearfix\"></div>
    </div>
    <div class=\"panel-wrapper collapse in\">
    <div class=\"panel-body\">
    <div class=\"chat-content\">
    <ul>
    <li class=\"friend\">
    <div class=\"friend-msg-wrap\"></div> 
    </li>
    <li class=\"self\">
    <div class=\"self-msg-wrap\">
    </div>  
    </li>
    <li class=\"friend\">
    <div class=\"friend-msg-wrap\"></div> 
    </li>
    </ul>
    </div>
    <div class=\"input-group\">
    <div class=\"input-group-btn\">
    <div class=\"dropup\">
    <button type=\"button\" class=\"btn  btn-default  dropdown-toggle\" data-toggle=\"dropdown\" ><i class=\"fa fa-smile-o\"></i></button>
    <ul class=\"dropdown-menu dropdown-menu-right\">
    </ul>
</div></div>
<input type=\"text\" id=\"input_msg_send\" name=\"send-msg\" class=\"form-control\" placeholder=\"Type something\">
<div class=\"input-group-btn\">
<div class=\"fileupload btn  btn-default\"><i class=\"fa fa-paperclip\">
</i>
<input type=\"file\" class=\"upload\">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id=\"messages_tab\" class=\"tab-pane fade\" role=\"tabpanel\">
<div class=\"message-box-wrap\">
<div class=\"streamline message-box\">
<div class=\"sl-item\">
<div class=\"sl-avatar avatar avatar-sm avatar-circle\">
<img class=\"img-responsive img-circle\" src=\"{{asset('dist/img/user.png') }}\" alt=\"avatar\"/>
</div>
<div class=\"sl-content\">
<a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
<span class=\"inline-block font-12 mb-5 pull-right\">12/10/16</span>
<div class=\"clearfix\"></div>
<p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
</div></div><hr/>
<div class=\"sl-item\">
<div class=\"sl-avatar avatar avatar-sm avatar-circle\">
<img class=\"img-responsive img-circle\" src=\"{{asset('dist/img/user1.png') }}\" alt=\"avatar\"/>
</div>
<div class=\"sl-content\">
<a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
<span class=\"inline-block font-12 mb-5 pull-right\">2pm</span>
<div class=\"clearfix\"></div>
<p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
</div>
</div>
<hr/>
<div class=\"sl-item\">
                                                <div class=\"sl-avatar avatar avatar-sm avatar-circle\">
                                                    <img class=\"img-responsive img-circle\" src=\"{{asset('dist/img/user2.png') }}\" alt=\"avatar\"/>
                                                </div>
                                                <div class=\"sl-content\">
                                                    <a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
                                                    <span class=\"inline-block font-12 mb-5 pull-right\">1pm</span>
                                                    <div class=\"clearfix\"></div>
                                                    <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
                                                </div>
                                            </div>
                                            <hr/>
                                            <div class=\"sl-item\">
                                                <div class=\"sl-avatar avatar avatar-sm avatar-circle\">
                                                    <img class=\"img-responsive img-circle\" src=\"{{asset('dist/img/user3.png') }}\" alt=\"avatar\"/>
                                                </div>
                                                <div class=\"sl-content\">
                                                    <a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
                                                    <span class=\"inline-block font-12 mb-5 pull-right\">1pm</span>
                                                    <div class=\"clearfix\"></div>
                                                    <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
                                                </div>
                                            </div>
                                            <hr/>
                                            <div class=\"sl-item\">
                                                <div class=\"sl-avatar avatar avatar-sm avatar-circle\">
                                                    <img class=\"img-responsive img-circle\" src=\"{{asset('dist/img/user4.png') }}\" alt=\"avatar\"/>
                                                </div>
                                                <div class=\"sl-content\">
                                                    <a href=\"javascript:void(0)\" class=\"inline-block capitalize-font  mb-5 pull-left\">Sandy Doe</a>
                                                    <span class=\"inline-block font-12 mb-5 pull-right\">1pm</span>
                                                    <div class=\"clearfix\"></div>
                                                    <p>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div  id=\"todo_tab\" class=\"tab-pane fade\" role=\"tabpanel\">
                                    <div class=\"todo-box-wrap\">
                                        
                                        <ul class=\"todo-list\">
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-default\">
                                                    <input type=\"checkbox\" id=\"checkbox01\"/>
                                                    <label for=\"checkbox01\">Record The First Episode Of HTML Tutorial</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-pink\">
                                                    <input type=\"checkbox\" id=\"checkbox02\"/>
                                                    <label for=\"checkbox02\">Prepare The Conference Schedule</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-warning\">
                                                    <input type=\"checkbox\" id=\"checkbox03\" checked/>
                                                    <label for=\"checkbox03\">Decide The Live Discussion Time</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-success\">
                                                    <input type=\"checkbox\" id=\"checkbox04\" checked/>
                                                    <label for=\"checkbox04\">Prepare For The Next Project</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-danger\">
                                                    <input type=\"checkbox\" id=\"checkbox05\" checked/>
                                                    <label for=\"checkbox05\">Finish Up AngularJs Tutorial</label>
                                                </div>
                                            </li>
                                            <li class=\"todo-item\">
                                                <div class=\"checkbox checkbox-purple\">
                                                    <input type=\"checkbox\" id=\"checkbox06\" checked/>
                                                    <label for=\"checkbox06\">Finish Infinity Project</label>
                                                </div>
                                            </li>
                                        </ul>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
 {% block body %}{% endblock %}
        
          
            
            
        </div>
       

    </div>



    </div>{# wrapper class end#}

    
    <script src=\"{{asset('vendors/bower_components/jquery/dist/jquery.min.js') }}\"></script>


    <script src=\"{{asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js') }}\"></script>
    
\t<script src=\"{{asset('dist/js/dataTables-data.js') }}\"></script>
    
\t<script src=\"{{asset('vendors/bower_components/datatables/media/js/jquery.dataTables.min.js') }}\"></script>
\t
 
\t<script src=\"{{asset('dist/js/jquery.slimscroll.js') }}\"></script>
\t
\t
\t<script src=\"{{asset('vendors/bower_components/moment/min/moment.min.js') }}\"></script>
\t<script src=\"{{asset('vendors/bower_components/simpleWeather/jquery.simpleWeather.min.js') }}\"></script>
\t<script src=\"{{asset('dist/js/simpleweather-data.js') }}\"></script>
\t
\t
\t<script src=\"{{asset('vendors/bower_components/waypoints/lib/jquery.waypoints.min.js') }}\"></script>
\t<script src=\"{{asset('vendors/bower_components/Counter-Up/jquery.counterup.min.js') }}\"></script>
\t

\t<script src=\"{{asset('dist/js/dropdown-bootstrap-extended.js') }}\"></script>
\t

        <script src=\"{{ asset('vendors/bower_components/dropzone/dist/dropzone.js') }}\"></script>


\t<script src=\"{{asset('vendors/jquery.sparkline/dist/jquery.sparkline.min.js') }}\"></script>
\t

\t<script src=\"{{asset('vendors/chart.js/Chart.min.js') }}\"></script>
\t

    <script src=\"{{asset('vendors/bower_components/raphael/raphael.min.js') }}\"></script>
    <script src=\"{{asset('vendors/bower_components/morris.js/morris.min.js') }}\"></script>
    <script src=\"{{asset('dist/js/morris-data.js') }}\"></script>
\t
\t<script src=\"{{asset('vendors/bower_components/jquery-toast-plugin/dist/jquery.toast.min.js') }}\"></script>
\t

\t<script src=\"{{ asset('dist/js/init.js') }}\"></script>
\t<script src=\"{{ asset('dist/js/dashboard_data.js') }}\"></script>
    <script>
\$('body').on('click','.confirmation' , function () {
        return confirm('Are you sure?');
    });

\$('#typeofpath').on('change',function(){
var rok = \$(this).val();
if( rok == 'dropbox' )
{
\$('.catype').css('display','block');
    
}
else{
\$('.catype').css('display','none');
}
});



\$(document).ready(function() {
\$(\"#topcat\").change(function () {
var option = \$('option:selected', this).val();
      \$(\"#unlockcat\")
          .find(\"option\")
          .show()
          .not(\"option[toparent~='\" + option + \"']\").hide();
     
   \$(\"#unlockcat\").val(
      \$(\"#unlockcat\").find(\"option:visible:first\").val()); 
  }).change();


\$(\"#topcatedit\").on('change', function () {

var option = \$('option:selected', this).val();
\$(\"#unlockcatedit\")
          .find(\"option\")
          .show()
          .not(\"option[toparent~='\" + option + \"']\").hide();

    \$(\"#unlockcatedit\").val(
      \$(\"#unlockcatedit\").find(\"option:visible:first\").val());       
});
});

\$('#typeofpath').on('change',function(){
var resourcetype = \$(this).val();
if(resourcetype == 'dropbox'){

\$('#resourcetype').attr('required','required');
}else{

\$('#resourcetype').removeAttr('required');

}


});

    </script>
<style>
.footer{
position:relative!important;  
}
</style>
</body>

</html>", "adminlayout.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/adminlayout.html.twig");
    }
}
