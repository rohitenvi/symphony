<?php

/* frontend/latestnews.html.twig */
class __TwigTemplate_c8323664f0e0ddf59fc14ed5d105ae02997186e12db45e2749e3c71e761279de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("home.html.twig", "frontend/latestnews.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "home.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a48622884987f6f5f8030cbacd3fc8aa40103b130546152f12c2eb39b57557b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a48622884987f6f5f8030cbacd3fc8aa40103b130546152f12c2eb39b57557b->enter($__internal_8a48622884987f6f5f8030cbacd3fc8aa40103b130546152f12c2eb39b57557b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontend/latestnews.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8a48622884987f6f5f8030cbacd3fc8aa40103b130546152f12c2eb39b57557b->leave($__internal_8a48622884987f6f5f8030cbacd3fc8aa40103b130546152f12c2eb39b57557b_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_b6065dfa4eefce97a9c17dd55bc628340fabad07944e03f7db988db087444579 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6065dfa4eefce97a9c17dd55bc628340fabad07944e03f7db988db087444579->enter($__internal_b6065dfa4eefce97a9c17dd55bc628340fabad07944e03f7db988db087444579_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<section class=\"slider slider-5\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-6 pad-0\">
            <h2>
                <span>Latest News</span>
                <img class=\"hidden visible-xs\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/news-white.png"), "html", null, true);
        echo "\" alt=\"mob-home\">
            </h2>
            <p>Some text will go here relating to the Grant Holders and Project Team. Maybe explaining the difference between the two and the fact the Project Team seem to be know as investigators.</p>
             </div>
        </div>
    </div>
</section>


";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allnews"]) ? $context["allnews"] : $this->getContext($context, "allnews")));
        foreach ($context['_seq'] as $context["_key"] => $context["news"]) {
            // line 19
            echo "

<section class=\"latest-news-section light\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3 col-md-offset-2 col-sm-3 col-xs-12 news-img\">
                    
                     ";
            // line 26
            if ( !twig_test_empty($this->getAttribute($context["news"], "imagePath", array()))) {
                // line 27
                echo "                    <img src=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
                echo "uploads/newsimages/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["news"], "imagePath", array()), "html", null, true);
                echo "\" alt=\"image\">
                    ";
            } else {
                // line 29
                echo "                    <img src=\"";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
                echo "uploads/newsimages/nonewsimage.png\" alt=\"image\">
                    ";
            }
            // line 31
            echo "                
            </div>
            <div class=\"col-md-5 col-sm-9 col-xs-12 news-detail\">
           <a href=\"";
            // line 34
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
            echo "news/";
            echo twig_escape_filter($this->env, $this->env->getExtension('Cocur\Slugify\Bridge\Twig\SlugifyExtension')->slugifyFilter($this->getAttribute($context["news"], "name", array())), "html", null, true);
            echo "/";
            echo twig_escape_filter($this->env, $this->getAttribute($context["news"], "id", array()), "html", null, true);
            echo "\"  >     <h2>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["news"], "name", array()), "html", null, true);
            echo "</h2> </a>
                <p class=\"sub-heading\">By ";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["news"], "author", array()), "html", null, true);
            echo "</p>
                
                <p>Publication date: <span>";
            // line 37
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["news"], "added", array()), "d F Y"), "html", null, true);
            echo "</span></p>
            </div>
        </div>
    </div>
</section>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['news'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "
";
        
        $__internal_b6065dfa4eefce97a9c17dd55bc628340fabad07944e03f7db988db087444579->leave($__internal_b6065dfa4eefce97a9c17dd55bc628340fabad07944e03f7db988db087444579_prof);

    }

    public function getTemplateName()
    {
        return "frontend/latestnews.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 43,  109 => 37,  104 => 35,  94 => 34,  89 => 31,  83 => 29,  75 => 27,  73 => 26,  64 => 19,  60 => 18,  48 => 9,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'home.html.twig' %}
{% block body %}
<section class=\"slider slider-5\">
 <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-6 pad-0\">
            <h2>
                <span>Latest News</span>
                <img class=\"hidden visible-xs\" src=\"{{ asset('vendors/frontend/images/news-white.png') }}\" alt=\"mob-home\">
            </h2>
            <p>Some text will go here relating to the Grant Holders and Project Team. Maybe explaining the difference between the two and the fact the Project Team seem to be know as investigators.</p>
             </div>
        </div>
    </div>
</section>


{% for news in allnews %}


<section class=\"latest-news-section light\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-3 col-md-offset-2 col-sm-3 col-xs-12 news-img\">
                    
                     {% if news.imagePath is not empty %}
                    <img src=\"{{ url('homepage') }}uploads/newsimages/{{ news.imagePath }}\" alt=\"image\">
                    {% else %}
                    <img src=\"{{ url('homepage') }}uploads/newsimages/nonewsimage.png\" alt=\"image\">
                    {%endif%}
                
            </div>
            <div class=\"col-md-5 col-sm-9 col-xs-12 news-detail\">
           <a href=\"{{ url('homepage') }}news/{{ news.name |slugify }}/{{news.id}}\"  >     <h2>{{ news.name }}</h2> </a>
                <p class=\"sub-heading\">By {{ news.author }}</p>
                
                <p>Publication date: <span>{{ news.added |date(\"d F Y\") }}</span></p>
            </div>
        </div>
    </div>
</section>
{% endfor %}

{% endblock %}", "frontend/latestnews.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/frontend/latestnews.html.twig");
    }
}
