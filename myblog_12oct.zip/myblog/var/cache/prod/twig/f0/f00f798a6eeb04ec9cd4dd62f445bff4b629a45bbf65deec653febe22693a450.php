<?php

/* frontend/homepage.html.twig */
class __TwigTemplate_1827ca1c593f9072a4fd468951bda7b2de62d3a0bbd8f4b7f9c9805fbe6dc769 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("home.html.twig", "frontend/homepage.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "home.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e3e2dfe392e218dde02bf7deed6dad1eb06e631cb3f274113e5bbb2f599b4c60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3e2dfe392e218dde02bf7deed6dad1eb06e631cb3f274113e5bbb2f599b4c60->enter($__internal_e3e2dfe392e218dde02bf7deed6dad1eb06e631cb3f274113e5bbb2f599b4c60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontend/homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e3e2dfe392e218dde02bf7deed6dad1eb06e631cb3f274113e5bbb2f599b4c60->leave($__internal_e3e2dfe392e218dde02bf7deed6dad1eb06e631cb3f274113e5bbb2f599b4c60_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_8ac0edc3d632d1006a70d06f80bd1cc9772cc246f84d430ecc32a3b5be3c6822 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ac0edc3d632d1006a70d06f80bd1cc9772cc246f84d430ecc32a3b5be3c6822->enter($__internal_8ac0edc3d632d1006a70d06f80bd1cc9772cc246f84d430ecc32a3b5be3c6822_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "
<section class=\"slider\">
    <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-8 pad-0\">
            <h2>
                <span>Advancing and Applying the science of Behaviour Change through Machine-Learning</span>
                <img class=\"hidden visible-xs\" src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/mob-home.png"), "html", null, true);
        echo "\" alt=\"mob-home\">
            </h2>
            <p>The Human Behaviour Change Project is a collaboration between world leading institution to create and develop a Machine Learning Programme that can analyse and literature and no more text</p>
        </div>
        </div>
    </div>
</section>
<section class=\"logo-bar\">
    <p class=\"text-center\">
        <img src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/home-sponsors.svg"), "html", null, true);
        echo " \" alt=\"home-sponsors\">
    </p>
</section>
<section class=\"block block-1 light\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-6 col-sm-push-6\">
                <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/homegraphic-bc.svg"), "html", null, true);
        echo "\" alt=\"Homegraphic Behavioural Science\">
            </div>
            <div class=\"col-sm-6 col-sm-pull-6\">
                <h2>Behavioural Science</h2>
                <p>This part of the project involves developing and applying a system for structuring knowledge about behaviou change interventions.</p>
                <a href=\"\" class=\"btn\">Behavioural Science Resources</a>
            </div>
            
        </div>
    </div>
</section>
    <section class=\"block block-1\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-6\">
                <img src=\"";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/homegraphic-cs.svg"), "html", null, true);
        echo "\" alt=\"Homegraphic Computer Science\">
            </div>
            <div class=\"col-sm-6\">
                <h2>Computer Science</h2>
                <p>This department involves developing automated systems for reading the research literature and synthesising evidence.</p>
                <a href=\"\" class=\"btn\">Computer Science Resources</a>
            </div>
            
        </div>
    </div>
</section>
<section class=\"block block-2 light\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-6 col-sm-push-6\">
                <img src=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/homegraphic-sa.svg"), "html", null, true);
        echo "\" alt=\"Homegraphic System Architecture\">
            </div>
            <div class=\"col-sm-6 col-sm-pull-6\">
                <h2>System Architecture</h2>
                <p>The system architects develop and evaluate an interface for computers and humans to interact with the knowledge system.</p>
                <a href=\"\" class=\"btn\">System Architecture Resources</a>
            </div> 
        </div>
    </div>
</section>
<section class=\"block block-3 text-center bg-img \">
    <div class=\"container \">
        <div class=\"row\">
            <div class=\"custom-block bg-icon\">
                <div class=\"icon\">
                    <img src=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/homeicon-team.svg"), "html", null, true);
        echo "\" alt=\"team-icon\">
                </div>
                <h2>Who's Involved</h2>
                <p>The project is managed investigators based in academic institutions from around the world and those involved are at the forefront of the technical and managerial aspects of the project.</p>
                <a href=\"\" class=\"btn\">Grant Holders & Project Team</a>
            </div>
            <div class=\"spacer\"></div>
            <div class=\"custom-block bg-icon-2\">
                <div class=\"icon\">
                    <img src=\"";
        // line 80
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/homeicon-news.svg"), "html", null, true);
        echo "\" alt=\"news-icon\">
                </div>
                <h2>HBCP News</h2>
                <p>Keep up to date with the latest news from the HBCP ranging from the progress of the project to confrences previews and review, comments on machine learning press releases and much more.</p>
                <a href=\"\" class=\"btn\">Latest News</a>
            </div>
        </div>
    </div>
</section>
";
        
        $__internal_8ac0edc3d632d1006a70d06f80bd1cc9772cc246f84d430ecc32a3b5be3c6822->leave($__internal_8ac0edc3d632d1006a70d06f80bd1cc9772cc246f84d430ecc32a3b5be3c6822_prof);

    }

    public function getTemplateName()
    {
        return "frontend/homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 80,  125 => 71,  107 => 56,  89 => 41,  71 => 26,  61 => 19,  49 => 10,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'home.html.twig' %}
{% block body %}

<section class=\"slider\">
    <div class=\"container\">
        <div class=\"row\">
        <div class=\"col-md-6 col-sm-8 pad-0\">
            <h2>
                <span>Advancing and Applying the science of Behaviour Change through Machine-Learning</span>
                <img class=\"hidden visible-xs\" src=\"{{ asset('vendors/frontend/images/mob-home.png') }}\" alt=\"mob-home\">
            </h2>
            <p>The Human Behaviour Change Project is a collaboration between world leading institution to create and develop a Machine Learning Programme that can analyse and literature and no more text</p>
        </div>
        </div>
    </div>
</section>
<section class=\"logo-bar\">
    <p class=\"text-center\">
        <img src=\"{{ asset('vendors/frontend/images/home-sponsors.svg') }} \" alt=\"home-sponsors\">
    </p>
</section>
<section class=\"block block-1 light\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-6 col-sm-push-6\">
                <img src=\"{{ asset('vendors/frontend/images/homegraphic-bc.svg') }}\" alt=\"Homegraphic Behavioural Science\">
            </div>
            <div class=\"col-sm-6 col-sm-pull-6\">
                <h2>Behavioural Science</h2>
                <p>This part of the project involves developing and applying a system for structuring knowledge about behaviou change interventions.</p>
                <a href=\"\" class=\"btn\">Behavioural Science Resources</a>
            </div>
            
        </div>
    </div>
</section>
    <section class=\"block block-1\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-6\">
                <img src=\"{{ asset('vendors/frontend/images/homegraphic-cs.svg') }}\" alt=\"Homegraphic Computer Science\">
            </div>
            <div class=\"col-sm-6\">
                <h2>Computer Science</h2>
                <p>This department involves developing automated systems for reading the research literature and synthesising evidence.</p>
                <a href=\"\" class=\"btn\">Computer Science Resources</a>
            </div>
            
        </div>
    </div>
</section>
<section class=\"block block-2 light\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-sm-6 col-sm-push-6\">
                <img src=\"{{ asset('vendors/frontend/images/homegraphic-sa.svg') }}\" alt=\"Homegraphic System Architecture\">
            </div>
            <div class=\"col-sm-6 col-sm-pull-6\">
                <h2>System Architecture</h2>
                <p>The system architects develop and evaluate an interface for computers and humans to interact with the knowledge system.</p>
                <a href=\"\" class=\"btn\">System Architecture Resources</a>
            </div> 
        </div>
    </div>
</section>
<section class=\"block block-3 text-center bg-img \">
    <div class=\"container \">
        <div class=\"row\">
            <div class=\"custom-block bg-icon\">
                <div class=\"icon\">
                    <img src=\"{{ asset('vendors/frontend/images/homeicon-team.svg') }}\" alt=\"team-icon\">
                </div>
                <h2>Who's Involved</h2>
                <p>The project is managed investigators based in academic institutions from around the world and those involved are at the forefront of the technical and managerial aspects of the project.</p>
                <a href=\"\" class=\"btn\">Grant Holders & Project Team</a>
            </div>
            <div class=\"spacer\"></div>
            <div class=\"custom-block bg-icon-2\">
                <div class=\"icon\">
                    <img src=\"{{ asset('vendors/frontend/images/homeicon-news.svg') }}\" alt=\"news-icon\">
                </div>
                <h2>HBCP News</h2>
                <p>Keep up to date with the latest news from the HBCP ranging from the progress of the project to confrences previews and review, comments on machine learning press releases and much more.</p>
                <a href=\"\" class=\"btn\">Latest News</a>
            </div>
        </div>
    </div>
</section>
{% endblock %}", "frontend/homepage.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/frontend/homepage.html.twig");
    }
}
