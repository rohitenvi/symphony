<?php

/* frontend/singleresource.html.twig */
class __TwigTemplate_c032ed20885cd0fa58459efae033dfe04348bfa00b6e4ccf6ba6a9e1f691cb6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("home.html.twig", "frontend/singleresource.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "home.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b9e3fc93083e09a35dc72ce1510b486eeb7cd6d51a64083c8971f15fbd4f796f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9e3fc93083e09a35dc72ce1510b486eeb7cd6d51a64083c8971f15fbd4f796f->enter($__internal_b9e3fc93083e09a35dc72ce1510b486eeb7cd6d51a64083c8971f15fbd4f796f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontend/singleresource.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b9e3fc93083e09a35dc72ce1510b486eeb7cd6d51a64083c8971f15fbd4f796f->leave($__internal_b9e3fc93083e09a35dc72ce1510b486eeb7cd6d51a64083c8971f15fbd4f796f_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_fa56a79f22e746f6c87f4972973aed6c31ac56762c46cf28f58901261a337c37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa56a79f22e746f6c87f4972973aed6c31ac56762c46cf28f58901261a337c37->enter($__internal_fa56a79f22e746f6c87f4972973aed6c31ac56762c46cf28f58901261a337c37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<section class=\" article-slider\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12 col-sm-12 col-xs-12 pad-0\">
                <a href=\"#\">Back To Resource</a>
                <h2 class=\"text-center\">
                    <span>2017 Review of Human Behaviour Change Project</span>
                    <!-- <img class=\"hidden visible-xs\" src=\"images/news-white.png\" alt=\"mob-home\"> -->
                </h2>
                <p class=\"text-center\">Powerpoint Slide</p>
            </div>
        </div>
    </div>
</section>
<section class=\"dropbox-section light\">
    <div class=\"container\">
        <div class=\"col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-12\">
            <div class=\"row\">
                <div class=\"col-md-4 col-sm-4 col-xs-4 pad-0drop-img text-right\">
                    <img src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/dropbox.png"), "html", null, true);
        echo "\" alt=\"image\">
                </div>
                <div class=\"col-md-8 col-sm-4 col-xs-4 pad-0 drop-txt text-center\">
                    <p>We use Dropbox to host all our resource documents</p>
                </div>
            </div>
            <a href=\"#\" class=\"download-btn btn\">
                <p>Download Resource</p>
                <span>154mb</span>
            </a>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">Department</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">Behavioural Science</div>
            </div>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">Category</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">Exposure Reach / General</div>
            </div>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">uploaded</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">21/2/2016</div>
            </div>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">Resource ID</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">214255124</div>
            </div>
        </div>
    </div>
</section>

<section class=\"share-resource\">
    <div class=\"contanier\">
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12\" >
                <h2>Share Resource</h2>
                <form class=\"link-bar\">
                    <div class=\"input-group\">
                        <input type=\"text\" class=\"link-input\" placeholder=\"https://humanbehaviourchange.org/resources/linkname-20132142151\" name=\"search\">
                        <div class=\"input-group-btn\">
                            <button class=\"btn copy-btn\" type=\"submit\">Copy Link</button>
                        </div>
                    </div>
                </form>
                <p>Share with Networks</p>
                <ul class=\"social-icons\">
                    <li><a href=\"#\"><img src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/fb.png"), "html", null, true);
        echo "\" alt=\"social-icon\"></a></li>
                    <li><a href=\"#\"><img src=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/tw.png"), "html", null, true);
        echo "\" alt=\"social-icon\"></a></li>
                    <li><a href=\"#\"><img src=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendors/frontend/images/li.png"), "html", null, true);
        echo "\" alt=\"social-icon\"></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class=\"back-btn\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12 col-sm-12 col-xs-12\">
                <a href=\"#\" class=\"btn\">Back To Resource</a>
            </div>
        </div>
    </div>
</section>
";
        
        $__internal_fa56a79f22e746f6c87f4972973aed6c31ac56762c46cf28f58901261a337c37->leave($__internal_fa56a79f22e746f6c87f4972973aed6c31ac56762c46cf28f58901261a337c37_prof);

    }

    public function getTemplateName()
    {
        return "frontend/singleresource.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 69,  113 => 68,  109 => 67,  61 => 22,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'home.html.twig' %}
{% block body %}
<section class=\" article-slider\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12 col-sm-12 col-xs-12 pad-0\">
                <a href=\"#\">Back To Resource</a>
                <h2 class=\"text-center\">
                    <span>2017 Review of Human Behaviour Change Project</span>
                    <!-- <img class=\"hidden visible-xs\" src=\"images/news-white.png\" alt=\"mob-home\"> -->
                </h2>
                <p class=\"text-center\">Powerpoint Slide</p>
            </div>
        </div>
    </div>
</section>
<section class=\"dropbox-section light\">
    <div class=\"container\">
        <div class=\"col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-12\">
            <div class=\"row\">
                <div class=\"col-md-4 col-sm-4 col-xs-4 pad-0drop-img text-right\">
                    <img src=\"{{ asset('vendors/frontend/images/dropbox.png') }}\" alt=\"image\">
                </div>
                <div class=\"col-md-8 col-sm-4 col-xs-4 pad-0 drop-txt text-center\">
                    <p>We use Dropbox to host all our resource documents</p>
                </div>
            </div>
            <a href=\"#\" class=\"download-btn btn\">
                <p>Download Resource</p>
                <span>154mb</span>
            </a>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">Department</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">Behavioural Science</div>
            </div>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">Category</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">Exposure Reach / General</div>
            </div>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">uploaded</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">21/2/2016</div>
            </div>
            <div class=\"row\">
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-main-heading\">Resource ID</div>
                <div class=\" col-md-6 col-sm-6 col-xs-6 drop-sub-heading\">214255124</div>
            </div>
        </div>
    </div>
</section>

<section class=\"share-resource\">
    <div class=\"contanier\">
        <div class=\"row\">
            <div class=\"col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12\" >
                <h2>Share Resource</h2>
                <form class=\"link-bar\">
                    <div class=\"input-group\">
                        <input type=\"text\" class=\"link-input\" placeholder=\"https://humanbehaviourchange.org/resources/linkname-20132142151\" name=\"search\">
                        <div class=\"input-group-btn\">
                            <button class=\"btn copy-btn\" type=\"submit\">Copy Link</button>
                        </div>
                    </div>
                </form>
                <p>Share with Networks</p>
                <ul class=\"social-icons\">
                    <li><a href=\"#\"><img src=\"{{ asset('vendors/frontend/images/fb.png') }}\" alt=\"social-icon\"></a></li>
                    <li><a href=\"#\"><img src=\"{{ asset('vendors/frontend/images/tw.png') }}\" alt=\"social-icon\"></a></li>
                    <li><a href=\"#\"><img src=\"{{ asset('vendors/frontend/images/li.png') }}\" alt=\"social-icon\"></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class=\"back-btn\">
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12 col-sm-12 col-xs-12\">
                <a href=\"#\" class=\"btn\">Back To Resource</a>
            </div>
        </div>
    </div>
</section>
{% endblock %}", "frontend/singleresource.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/frontend/singleresource.html.twig");
    }
}
