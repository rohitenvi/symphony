<?php

/* /admin/resources/createresource.html.twig */
class __TwigTemplate_4905935c3bcdae7f5ab61856aa046b007c19c1fb7f25eb34e37422ef1c321c75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("adminlayout.html.twig", "/admin/resources/createresource.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "adminlayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df20daeb7bc7ddd22229c49cb210049409fbcb68878584ba7e9d1d42ee2f03c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df20daeb7bc7ddd22229c49cb210049409fbcb68878584ba7e9d1d42ee2f03c9->enter($__internal_df20daeb7bc7ddd22229c49cb210049409fbcb68878584ba7e9d1d42ee2f03c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/admin/resources/createresource.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_df20daeb7bc7ddd22229c49cb210049409fbcb68878584ba7e9d1d42ee2f03c9->leave($__internal_df20daeb7bc7ddd22229c49cb210049409fbcb68878584ba7e9d1d42ee2f03c9_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_d52cf40ffb0f8fab476da55bc235f655698ad6b3f9544efcc61fd9aad91d1659 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d52cf40ffb0f8fab476da55bc235f655698ad6b3f9544efcc61fd9aad91d1659->enter($__internal_d52cf40ffb0f8fab476da55bc235f655698ad6b3f9544efcc61fd9aad91d1659_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"panel panel-default card-view\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Create  A  News</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"form-wrap\">
";
        // line 17
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "has", array(0 => "urlinvalid"), "method")) {
            // line 18
            echo "        <div class=\"alert alert-danger fade in\" role=\"alert\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
            ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "urlinvalid"), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 21
                echo "                ";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 23
            echo "        </div>
    ";
        }
        // line 25
        echo "
 <form action=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("homepage");
        echo "admin/resource/savenew\" method=\"post\" enctype=\"multipart/form-data\">
  <div class=\"form-group\">
    <label for=\"nameofresource\">Title of Resource:</label>
    <input type=\"text\" class=\"form-control\" id=\"nameofresource\" name=\"resourcename\" required>
  </div>
  <div class=\"form-group\">
  <label for=\"typeofpath\">Link Type:</label>
  <select class=\"form-control\" name=\"pathtype\" id=\"typeofpath\" required>
  <option value=\"\">--Please Select Link Type--</option>
    <option value=\"dropbox\">DropBox</option>
    <option value=\"website\">Website</option>
     <option value=\"tool\">Tool</option>
   </select>
  </div> 

 <div class=\"form-group catype\" style=\"display:none;\">
  <label for=\"resourcetype\">Resourcetype:</label>
  <select class=\"form-control\" name=\"resourcetype\" id=\"resourcetype\">
  ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resourcetypes"]) ? $context["resourcetypes"] : $this->getContext($context, "resourcetypes")));
        foreach ($context['_seq'] as $context["_key"] => $context["restype"]) {
            // line 45
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["restype"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["restype"], "name", array()), "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['restype'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 47
        echo "   </select>
  </div>

 

  <div class=\"form-group\" >
  <label for=\"dropboxlink\">Link:</label>
 <input type=\"textarea\" name=\"dropboxurl\" id=\"dropboxlink\" class=\"form-control\" required/>

  </div>

   <div class=\"form-group\">
  <label for=\"topcat\">Main Category:</label>
  <select class=\"form-control\" id=\"topcat\" name=\"topcategoryid\">
  ";
        // line 61
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resourcecategory"]) ? $context["resourcecategory"] : $this->getContext($context, "resourcecategory")));
        foreach ($context['_seq'] as $context["keys"] => $context["cats"]) {
            // line 62
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $context["keys"], "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["cats"], "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['keys'], $context['cats'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 64
        echo "   </select>
  </div>

 

  <div class=\"form-group\">
  <label for=\"unlockcat\">Sub Categories:</label>
  <select class=\"form-control\" name=\"catname\" id=\"unlockcat\" required>
  ";
        // line 72
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["resourceunlockeds"]) ? $context["resourceunlockeds"] : $this->getContext($context, "resourceunlockeds")));
        foreach ($context['_seq'] as $context["_key"] => $context["resourceunlocked"]) {
            // line 73
            echo "  <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resourceunlocked"], "id", array()), "html", null, true);
            echo "\" toparent=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resourceunlocked"], "parentId", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["resourceunlocked"], "name", array()), "html", null, true);
            echo "</option>
  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resourceunlocked'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "   </select>
  </div>

<button type=\"submit\" class=\"btn btn-default\">Submit</button>
</form> 
</div>
</div></div>
</div>
</div>
</div>
</div>
</div>
  ";
        
        $__internal_d52cf40ffb0f8fab476da55bc235f655698ad6b3f9544efcc61fd9aad91d1659->leave($__internal_d52cf40ffb0f8fab476da55bc235f655698ad6b3f9544efcc61fd9aad91d1659_prof);

    }

    public function getTemplateName()
    {
        return "/admin/resources/createresource.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 75,  163 => 73,  159 => 72,  149 => 64,  138 => 62,  134 => 61,  118 => 47,  107 => 45,  103 => 44,  82 => 26,  79 => 25,  75 => 23,  66 => 21,  62 => 20,  58 => 18,  56 => 17,  40 => 3,  34 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"adminlayout.html.twig\" %}
{% block body %}
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"panel panel-default card-view\">
<div class=\"panel-heading\">
<div class=\"pull-left\">
<h6 class=\"panel-title txt-dark\">Create  A  News</h6>
</div>
<div class=\"clearfix\"></div>
</div>
<div class=\"panel-wrapper collapse in\">
<div class=\"panel-body\">
<div class=\"row\">
<div class=\"col-md-12\">
<div class=\"form-wrap\">
{% if app.session.flashBag.has('urlinvalid') %}
        <div class=\"alert alert-danger fade in\" role=\"alert\">
            <a href=\"#\" class=\"close\" data-dismiss=\"alert\" aria-label=\"close\">&times;</a>
            {% for msg in app.session.flashBag.get('urlinvalid') %}
                {{ msg }}
            {% endfor %}
        </div>
    {% endif %}

 <form action=\"{{ url('homepage') }}admin/resource/savenew\" method=\"post\" enctype=\"multipart/form-data\">
  <div class=\"form-group\">
    <label for=\"nameofresource\">Title of Resource:</label>
    <input type=\"text\" class=\"form-control\" id=\"nameofresource\" name=\"resourcename\" required>
  </div>
  <div class=\"form-group\">
  <label for=\"typeofpath\">Link Type:</label>
  <select class=\"form-control\" name=\"pathtype\" id=\"typeofpath\" required>
  <option value=\"\">--Please Select Link Type--</option>
    <option value=\"dropbox\">DropBox</option>
    <option value=\"website\">Website</option>
     <option value=\"tool\">Tool</option>
   </select>
  </div> 

 <div class=\"form-group catype\" style=\"display:none;\">
  <label for=\"resourcetype\">Resourcetype:</label>
  <select class=\"form-control\" name=\"resourcetype\" id=\"resourcetype\">
  {%for  restype in resourcetypes %}
  <option value=\"{{ restype.id }}\">{{ restype.name}}</option>
  {% endfor %}
   </select>
  </div>

 

  <div class=\"form-group\" >
  <label for=\"dropboxlink\">Link:</label>
 <input type=\"textarea\" name=\"dropboxurl\" id=\"dropboxlink\" class=\"form-control\" required/>

  </div>

   <div class=\"form-group\">
  <label for=\"topcat\">Main Category:</label>
  <select class=\"form-control\" id=\"topcat\" name=\"topcategoryid\">
  {%for  keys,cats in resourcecategory %}
  <option value=\"{{ keys }}\">{{ cats }}</option>
  {% endfor %}
   </select>
  </div>

 

  <div class=\"form-group\">
  <label for=\"unlockcat\">Sub Categories:</label>
  <select class=\"form-control\" name=\"catname\" id=\"unlockcat\" required>
  {%for  resourceunlocked in resourceunlockeds %}
  <option value=\"{{ resourceunlocked.id }}\" toparent=\"{{resourceunlocked.parentId }}\">{{ resourceunlocked.name }}</option>
  {% endfor %}
   </select>
  </div>

<button type=\"submit\" class=\"btn btn-default\">Submit</button>
</form> 
</div>
</div></div>
</div>
</div>
</div>
</div>
</div>
  {% endblock %}", "/admin/resources/createresource.html.twig", "/opt/lampp/htdocs/myblog/app/Resources/views/admin/resources/createresource.html.twig");
    }
}
