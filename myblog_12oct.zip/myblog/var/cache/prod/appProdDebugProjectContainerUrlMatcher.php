<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        if (0 === strpos($pathinfo, '/b')) {
            if (0 === strpos($pathinfo, '/blog')) {
                // blog_list
                if (preg_match('#^/blog(?:/(?P<page>\\d+))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'blog_list')), array (  'page' => 1,  '_controller' => 'AppBundle\\Controller\\BlogController::listAction',));
                }

                // blog_show
                if (preg_match('#^/blog/(?P<slug>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'blog_show')), array (  '_controller' => 'AppBundle\\Controller\\BlogController::showAction',));
                }

            }

            // behaviourdiagram
            if ('/behaviour-diagram' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::BehaviourDiagramAction',  '_route' => 'behaviourdiagram',);
            }

            // behaviourscience
            if ('/behavioural-science' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::BehaviourAction',  '_route' => 'behaviourscience',);
            }

        }

        elseif (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/cat')) {
                // cats_list
                if ('/admin/cats/all' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\CategroyController::categoryindexAction',  '_route' => 'cats_list',);
                }

                // category_create
                if ('/admin/cat/create' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\CategroyController::creatercategoryAction',  '_route' => 'category_create',);
                }

                // category_save
                if ('/admin/cat/savenew' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\CategroyController::savecategoryAction',  '_route' => 'category_save',);
                }

                if (0 === strpos($pathinfo, '/admin/cat/edit')) {
                    // cat_edit
                    if (preg_match('#^/admin/cat/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ('GET' !== $canonicalMethod) {
                            $allow[] = 'GET';
                            goto not_cat_edit;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'cat_edit')), array (  '_controller' => 'AppBundle\\Controller\\CategroyController::editAction',));
                    }
                    not_cat_edit:

                    // cat_edit_save
                    if (preg_match('#^/admin/cat/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ('POST' !== $canonicalMethod) {
                            $allow[] = 'POST';
                            goto not_cat_edit_save;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'cat_edit_save')), array (  '_controller' => 'AppBundle\\Controller\\CategroyController::editcategorysaveAction',));
                    }
                    not_cat_edit_save:

                }

                // cat_delete
                if (0 === strpos($pathinfo, '/admin/cat/delete') && preg_match('#^/admin/cat/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'cat_delete')), array (  '_controller' => 'AppBundle\\Controller\\CategroyController::categorydeleteAction',));
                }

            }

            // news_create
            if ('/admin/createnew' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\NewsPostsController::createAction',  '_route' => 'news_create',);
            }

            // admindashboard
            if ('/admin/dashboard' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\LuckyController::admindashboard',  '_route' => 'admindashboard',);
            }

            // news_list
            if ('/admin/allnews' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\NewsPostsController::indexAction',  '_route' => 'news_list',);
            }

            // resources_list
            if ('/admin/allresources' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ResourcesController::allresourcesAction',  '_route' => 'resources_list',);
            }

            // news_edit
            if (0 === strpos($pathinfo, '/admin/news/edit') && preg_match('#^/admin/news/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'news_edit')), array (  '_controller' => 'AppBundle\\Controller\\NewsPostsController::editAction',));
            }

            // news_delete
            if (0 === strpos($pathinfo, '/admin/news/delete') && preg_match('#^/admin/news/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'news_delete')), array (  '_controller' => 'AppBundle\\Controller\\NewsPostsController::deleteAction',));
            }

            if (0 === strpos($pathinfo, '/admin/resource')) {
                if (0 === strpos($pathinfo, '/admin/resourcetype')) {
                    // resourcetype_list
                    if ('/admin/resourcetype/all' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ResourceTypeController::resourcetypeindexAction',  '_route' => 'resourcetype_list',);
                    }

                    // resourcetype_create
                    if ('/admin/resourcetype/create' === $pathinfo) {
                        return array (  '_controller' => 'AppBundle\\Controller\\ResourceTypeController::resourcetypecreateAction',  '_route' => 'resourcetype_create',);
                    }

                    // resourcetype_edit
                    if (0 === strpos($pathinfo, '/admin/resourcetype/edit') && preg_match('#^/admin/resourcetype/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'resourcetype_edit')), array (  '_controller' => 'AppBundle\\Controller\\ResourceTypeController::editresourcetypeAction',));
                    }

                    // resourcetype_delete
                    if (0 === strpos($pathinfo, '/admin/resourcetype/delete') && preg_match('#^/admin/resourcetype/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'resourcetype_delete')), array (  '_controller' => 'AppBundle\\Controller\\ResourceTypeController::resourcetypedeleteAction',));
                    }

                }

                // resource_create
                if ('/admin/resource/createnew' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\ResourcesController::createresourceAction',  '_route' => 'resource_create',);
                }

                // resource_save
                if ('/admin/resource/savenew' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\ResourcesController::saveresourceAction',  '_route' => 'resource_save',);
                }

                if (0 === strpos($pathinfo, '/admin/resources/edit')) {
                    // resources_edit
                    if (preg_match('#^/admin/resources/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ('GET' !== $canonicalMethod) {
                            $allow[] = 'GET';
                            goto not_resources_edit;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'resources_edit')), array (  '_controller' => 'AppBundle\\Controller\\ResourcesController::editresourceAction',));
                    }
                    not_resources_edit:

                    // resources_save
                    if (preg_match('#^/admin/resources/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ('POST' !== $canonicalMethod) {
                            $allow[] = 'POST';
                            goto not_resources_save;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'resources_save')), array (  '_controller' => 'AppBundle\\Controller\\ResourcesController::saveresourceeditAction',));
                    }
                    not_resources_save:

                }

                // resource_delete
                if (0 === strpos($pathinfo, '/admin/resource/delete') && preg_match('#^/admin/resource/delete/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'resource_delete')), array (  '_controller' => 'AppBundle\\Controller\\ResourcesController::resourcedeleteAction',));
                }

            }

        }

        // allresources
        if ('/all-resources' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::AllResourcesAction',  '_route' => 'allresources',);
        }

        // homepage
        if ('' === $trimmedPathinfo) {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
        }

        if (0 === strpos($pathinfo, '/l')) {
            // latestnews
            if ('/latest-news' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::latestnewsAction',  '_route' => 'latestnews',);
            }

            if (0 === strpos($pathinfo, '/lucky/number')) {
                // propage
                if ('/lucky/number' === $pathinfo) {
                    return array (  '_controller' => 'AppBundle\\Controller\\LuckyController::numberAction',  '_route' => 'propage',);
                }

                // app_lucky_numb
                if (preg_match('#^/lucky/number/(?P<max>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'app_lucky_numb')), array (  '_controller' => 'AppBundle\\Controller\\LuckyController::numbAction',));
                }

            }

            elseif (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ('/login' === $pathinfo) {
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_fos_user_security_login;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
                }
                not_fos_user_security_login:

                // fos_user_security_check
                if ('/login_check' === $pathinfo) {
                    if ('POST' !== $canonicalMethod) {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ('/logout' === $pathinfo) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_security_logout;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
            }
            not_fos_user_security_logout:

        }

        // singlenews_list
        if (0 === strpos($pathinfo, '/news') && preg_match('#^/news/(?P<slug>[^/]++)/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'singlenews_list')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::showooooAction',));
        }

        // contactus
        if ('/contact-us' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::contactusAction',  '_route' => 'contactus',);
        }

        // computerscience
        if ('/computer-science' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::ComputerScienceAction',  '_route' => 'computerscience',);
        }

        // projecteam
        if ('/project-team' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::teamembersAction',  '_route' => 'projecteam',);
        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if ('/profile' === $trimmedPathinfo) {
                if ('GET' !== $canonicalMethod) {
                    $allow[] = 'GET';
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ('/profile/edit' === $pathinfo) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_profile_edit;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }
            not_fos_user_profile_edit:

            // fos_user_change_password
            if ('/profile/change-password' === $pathinfo) {
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_change_password;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
            }
            not_fos_user_change_password:

        }

        // systemarchitect
        if ('/system-architecture' === $pathinfo) {
            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::SystemArchitectureAction',  '_route' => 'systemarchitect',);
        }

        if (0 === strpos($pathinfo, '/re')) {
            // singleresource
            if ('/resources' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::SingleResourcesAction',  '_route' => 'singleresource',);
            }

            if (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ('/resetting/request' === $pathinfo) {
                    if ('GET' !== $canonicalMethod) {
                        $allow[] = 'GET';
                        goto not_fos_user_resetting_request;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
                }
                not_fos_user_resetting_reset:

                // fos_user_resetting_send_email
                if ('/resetting/send-email' === $pathinfo) {
                    if ('POST' !== $canonicalMethod) {
                        $allow[] = 'POST';
                        goto not_fos_user_resetting_send_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ('/resetting/check-email' === $pathinfo) {
                    if ('GET' !== $canonicalMethod) {
                        $allow[] = 'GET';
                        goto not_fos_user_resetting_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                }
                not_fos_user_resetting_check_email:

            }

            elseif (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if ('/register' === $trimmedPathinfo) {
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_fos_user_registration_register;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
                }
                not_fos_user_registration_register:

                // fos_user_registration_check_email
                if ('/register/check-email' === $pathinfo) {
                    if ('GET' !== $canonicalMethod) {
                        $allow[] = 'GET';
                        goto not_fos_user_registration_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                }
                not_fos_user_registration_check_email:

                if (0 === strpos($pathinfo, '/register/confirm')) {
                    // fos_user_registration_confirm
                    if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                        if ('GET' !== $canonicalMethod) {
                            $allow[] = 'GET';
                            goto not_fos_user_registration_confirm;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                    }
                    not_fos_user_registration_confirm:

                    // fos_user_registration_confirmed
                    if ('/register/confirmed' === $pathinfo) {
                        if ('GET' !== $canonicalMethod) {
                            $allow[] = 'GET';
                            goto not_fos_user_registration_confirmed;
                        }

                        return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                    }
                    not_fos_user_registration_confirmed:

                }

            }

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
